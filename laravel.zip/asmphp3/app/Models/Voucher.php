<?php
// app/Models/Voucher.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Voucher extends Model
{
    use HasFactory;

    protected $fillable = [
        'code', 'type', 'value', 'expiration_date', 'usage_limit', 'times_used'
    ];

    public function isValid()
    {
        return $this->expiration_date >= now() && $this->times_used < $this->usage_limit;
    }

    public function applyDiscount($totalPrice, $shippingFee)
    {
        if ($this->type === 'fixed') {
            return [max(0, $totalPrice - $this->value), $shippingFee];
        } elseif ($this->type === 'percentage') {
            return [max(0, $totalPrice - ($totalPrice * $this->value / 100)), $shippingFee];
        } elseif ($this->type === 'shipping') {
            return [$totalPrice, max(0, $shippingFee - $this->value)];
        } else {
            return [$totalPrice, $shippingFee];
        }
    }

    public function hasBeenUsedBy($userId)
    {
        return $this->users()->where('user_id', $userId)->exists();
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'user_voucher');
    }
}