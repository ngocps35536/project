<?php
// app/Http/Controllers/ContactController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\GuiEmail;

class ContactController extends Controller
{
    public function showContactForm()
    {
        return view('contact');
    }

    public function sendContactEmail(Request $request)
    {
        $validatedData = $request->validate([
            'ht' => 'required|string',
            'em' => 'required|email',
            'nd' => 'required|string',
        ]);

        $hoten = $request->input('ht');
        $email = $request->input('em');
        $noidung = $request->input('nd');

        // Gửi email
        Mail::to('doanvanngoc061220@gmail.com')->send(new GuiEmail($hoten, $email, $noidung));

        // Redirect hoặc thông báo thành công
        return redirect()->back()->with('success', 'Email liên hệ đã được gửi thành công!');
    }
}
