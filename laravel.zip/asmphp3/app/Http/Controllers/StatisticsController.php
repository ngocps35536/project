<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\User;
use App\Models\Product;
use Illuminate\Http\Request;

class StatisticsController extends Controller
{
    public function index()
    {
        $totalOrders = Order::count();
        $totalUsers = User::count();
        $totalProducts = Product::count();
        $totalRevenue = Order::sum('total_price');

        return view('admin.statistics', compact('totalOrders', 'totalUsers', 'totalProducts', 'totalRevenue'));
    }
}
