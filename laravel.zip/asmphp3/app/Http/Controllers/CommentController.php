<?php
// app/Http/Controllers/CommentController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comment;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
    public function store(Request $request, $id)
    {
        $request->validate([
            'content' => 'required|string|max:255',
        ]);

        $productId = $id;

        if (!$productId) {
            return redirect()->back()->withErrors('Không thể xác định sản phẩm để bình luận.');
        }
        Comment::create([
            'user_id' => Auth::id(),
            'product_id' => $productId,
            'content' => $request->input('content'),
        ]);

        return redirect()->back()->with('success', 'Bình luận của bạn đã được thêm.');
    }
}
