<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function addToCart(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return redirect()->route('login')->with('error', 'Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng.');
        }

        // Lấy thông tin của sản phẩm từ request
        $product = Product::find($request->product_id);
        if (!$product) {
            return redirect()->back()->with('error', 'Sản phẩm không tồn tại.');
        }

        // Kiểm tra số lượng nhập vào, mặc định là 1 nếu không có số lượng được cung cấp
        $quantity = $request->input('quantity', 1);

        $validatedData = $request->validate([
            'quantity' => 'integer|min:1|max:' . $product->quantity,
            'product_id' => 'required|exists:products,id'
        ]);

        // Tìm giỏ hàng hoặc tạo mới nếu không tồn tại
        $cart = Cart::where('user_id', $user->id)->where('status', 'active')->firstOrCreate([
            'user_id' => $user->id,
            'status' => 'active'
        ]);

        // Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
        $cartItem = CartItem::where('cart_id', $cart->id)->where('product_id', $product->id)->first();

        // Nếu sản phẩm đã có trong giỏ hàng, tăng số lượng lên số lượng mới nhập vào
        if ($cartItem) {
            $cartItem->quantity += $validatedData['quantity'] ?? $quantity;
        } else {
            // Nếu sản phẩm chưa có trong giỏ hàng, tạo một mục mới trong giỏ hàng với số lượng mới nhập vào
            $cartItem = new CartItem([
                'cart_id' => $cart->id,
                'product_id' => $product->id,
                'quantity' => $validatedData['quantity'] ?? $quantity,
                'price' => $product->price
            ]);
        }
        $cartItem->save();

        return redirect()->back()->with('success', 'Sản phẩm đã được thêm vào giỏ hàng!');
    }


    public function showCart()
    {
        $cart = Cart::where('user_id', auth()->id())->where('status', 'active')->with('items.product')->first();

        return view('showcart', compact('cart'));
    }

    public function updateCartItem(Request $request)
    {
        $validatedData = $request->validate([
            'cart_item_id' => 'required|exists:cart_items,id',
            'quantity' => 'required|integer|min:1'
        ]);

        $cartItem = CartItem::find($validatedData['cart_item_id']);
        if (!$cartItem) {
            return redirect()->back()->with('error', 'Mục giỏ hàng không tồn tại.');
        }

        $cartItem->quantity = $validatedData['quantity'];
        $cartItem->save();

        return redirect()->back()->with('success', 'Mục giỏ hàng đã được cập nhật!');
    }


    public function removeCartItem($id)
    {
        $cartItem = CartItem::find($id);
        if (!$cartItem) {
            return redirect()->back()->with('error', 'Mục giỏ hàng không tồn tại.');
        }

        $cartItem->delete();

        return redirect()->back()->with('success', 'Mục giỏ hàng đã được xóa!');
    }
}
