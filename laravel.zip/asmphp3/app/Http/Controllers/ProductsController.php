<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use Illuminate\Pagination\Paginator;
use App\Models\Comment;
use App\Models\Product;
use App\Http\Resources\san_pham as SanPhamResource;

Paginator::useBootstrap();

class ProductsController extends Controller
{
    function index()
    {
        $sphot = DB::table('products')
            ->where('sale', '=', '25')
            ->orderBy('id', 'desc')
            ->limit(8)->get();

        $spview = DB::table('products')
            ->orderBy('view', 'desc')
            ->limit(8)->get();
        return view('home', ['sphot' => $sphot, 'spview' => $spview]);
    }
    function sptrongloai($id)
    {
        $ktraID = DB::table('categories')->where('id', $id)->exists();
        if (!$ktraID) {
            return view('404');
        }
        $dataLoai = DB::table('products')
            ->where('idCat', $id)
            ->orderBy('view', 'desc')
            ->paginate(8);

        // Lấy tên loại
        $ten = DB::table('categories')
            ->where('id', $id)
            ->value('name');
        // danh mục
        $data1 = DB::table('categories')
            ->select('id', 'name')
            ->get();

        return view('products', ['data' => $dataLoai, 'ten' => $ten, 'data1' => $data1]);
    }
    public function productDetail($id)
    {
        // check id product
        $ktraID = DB::table('products')->where('id', $id)->exists();
        if (!$ktraID) {
            return view('404');
        }
        // Tăng số lượt xem cho sản phẩm
        DB::table('products')->where('id', $id)->increment('view');

        // lấy ctiet
        $detail = DB::table('products')
            ->where('id', $id)
            ->first();

        // Lấy các sản phẩm liên quan cùng loại
        $relatedProducts = DB::table('products')
            ->where('idCat', $detail->idCat)
            ->where('id', '!=', $id)
            ->orderBy('price', 'desc')
            ->limit(4)
            ->get();

        // Lấy bình luận
        $comments = DB::table('comments')
            ->where('product_id', $id)
            ->join('users', 'comments.user_id', '=', 'users.id')
            ->select('comments.*', 'users.hoTen')
            ->get();

        return view('productsDetail', [
            'detail' => $detail,
            'relatedProducts' => $relatedProducts,
            'comments' => $comments
        ]);
    }

    public function search(Request $request)
    {
        $query = $request->input('query');
        $products = DB::table('products')
            ->where('name', 'like', "%{$query}%")
            ->get();

        return view('search', ['products' => $products, 'query' => $query]);
    }
    // call api cho server
    function test()
    {
        $listsp = Product::all();
        $data = SanPhamResource::collection($listsp);
        return response()->json($data);
    }
    function chi_tiet($id = 0)
    {
        $sp = Product::findOrFail($id);
        $data = new SanPhamResource($sp);
        return response()->json($data);
    }
}
