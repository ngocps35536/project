<?php

namespace App\Http\Controllers\AdminController;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use App\Models\Order;
use Illuminate\Pagination\Paginator;

Paginator::useBootstrap();
class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::orderBy('id', 'desc')->paginate(10);
        return view('admin.orders', compact('orders'));
    }

    public function show($id)
    {
        $order = Order::findOrFail($id);
        return view('admin.order_item', compact('order'));
    }

    public function edit($id)
    {
        $order = Order::findOrFail($id);
        return view('admin.order_edit', compact('order'));
    }

    public function update(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        // Validate the request data
        $request->validate([
            'address' => 'required|string|max:255',
            'payment_method' => 'required|string|max:50',
            'status' => 'required|in:pending,completed,canceled',
        ]);

        // Cập nhật thông tin đơn hàng
        $order->address = $request->input('address');
        $order->payment_method = $request->input('payment_method');
        $order->status = $request->input('status');
        $order->save();

        return redirect()->route('admin.orders.index')->with('success', 'Order updated successfully');
    }
}
