<?php

namespace App\Http\Controllers\AdminController;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use App\Models\Order;
use Illuminate\Pagination\Paginator;

Paginator::useBootstrap();

class SanphamController extends Controller
{

    public function admin()
    {
        $products = Product::withTrashed()->orderBy('id', 'desc')->paginate(10);
        return view('admin.products', ['products' => $products]);
    }

    public function create()
    {
        $categories = DB::table('categories')->get();
        return view('admin.createProduct', compact('categories'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'sale' => 'required|in:0,10,15,20,25',
            'quantity' => 'required|integer',
            'image' => 'nullable|string',
            'idCat' => 'required|exists:categories,id',
        ]);

        // $imagePath = $request->file('image') ? $request->file('image')->store('products', 'public') : null;

        Product::create([
            'name' => $validatedData['name'],
            'description' => $validatedData['description'],
            'price' => $validatedData['price'],
            'sale' => $validatedData['sale'],
            'quantity' => $validatedData['quantity'],
            'image' => $validatedData['image'],
            'idCat' => $validatedData['idCat'],
            'view' => 0,
        ]);

        return redirect('admin/products')->with('success', 'Sản phẩm đã được thêm thành công.');
    }

    public function edit($id)
    {
        $product = Product::withTrashed()->findOrFail($id);
        $categories = DB::table('categories')->get();
        return view('admin.editProduct', compact('product', 'categories'));
    }

    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric',
            'sale' => 'required|in:0,10,15,20,25',
            'quantity' => 'required|integer',
            'image' => 'nullable|image',
            'idCat' => 'required|exists:categories,id',
        ]);

        $product = Product::withTrashed()->findOrFail($id);
        $imagePath = $request->file('image') ? $request->file('image')->store('products', 'public') : $product->image;

        $product->update([
            'name' => $validatedData['name'],
            'description' => $validatedData['description'],
            'price' => $validatedData['price'],
            'sale' => $validatedData['sale'],
            'quantity' => $validatedData['quantity'],
            'image' => $imagePath,
            'idCat' => $validatedData['idCat'],
        ]);

        return redirect('admin/products')->with('success', 'Sản phẩm đã được cập nhật thành công.');
    }
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $product->delete();

        return redirect('admin/products')->with('success', 'Sản phẩm đã được xóa tạm thời.');
    }

    public function restore($id)
    {
        $product = Product::withTrashed()->findOrFail($id);
        $product->restore();

        return redirect('admin/products')->with('success', 'Sản phẩm đã được khôi phục.');
    }

    public function forceDelete($id)
    {
        $product = Product::withTrashed()->findOrFail($id);
        $product->forceDelete();

        return redirect('admin/products')->with('success', 'Sản phẩm đã được xóa vĩnh viễn.');
    }
}
