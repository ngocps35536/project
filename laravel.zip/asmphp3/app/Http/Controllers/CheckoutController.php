<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\UserVoucher;
use App\Models\Voucher;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\OrderConfirmation;

class CheckoutController extends Controller
{
    public function showCheckout()
    {
        $cart = Cart::where('user_id', auth()->id())->where('status', 'active')->with('items.product')->first();
        if (!$cart || $cart->items->isEmpty()) {
            return redirect()->route('cart.show')->with('error', 'Giỏ hàng của bạn đang trống.');
        }

        $user = auth()->user();

        return view('thanhtoan', compact('cart', 'user'));
    }
    public function applyVoucher(Request $request)
    {
        $validatedData = $request->validate([
            'voucher' => 'required|string|max:50',
        ]);

        $voucher = Voucher::where('code', $request->voucher)
            ->where('expiration_date', '>=', now())
            ->first();

        if ($voucher && $voucher->isValid() && !$voucher->hasBeenUsedBy(auth()->id())) {
            session(['voucher_code' => $request->voucher]);
            return redirect('/checkout')->with('success', 'Mã giảm giá đã được áp dụng thành công.');
        } else {
            return redirect('checkout')->with('error', 'Mã giảm giá không hợp lệ hoặc đã được sử dụng hết.');
        }
    }

    public function processCheckout(Request $request)
    {
        $validatedData = $request->validate([
            'address' => 'required|string|max:255',
            'payment_method' => 'required|string|max:50',
        ]);

        $cart = Cart::where('user_id', auth()->id())->where('status', 'active')->with('items.product')->first();

        if (!$cart || $cart->items->isEmpty()) {
            return redirect()->route('cart.show')->with('error', 'Giỏ hàng của bạn đang trống.');
        }

        $totalPrice = $cart->items->sum(function ($item) {
            return $item->price * $item->quantity;
        });

        $otp = rand(100000, 999999);

        $order = Order::create([
            'user_id' => auth()->id(),
            'address' => $request->address,
            'payment_method' => $request->payment_method,
            'total_price' => $totalPrice,
            'otp' => $otp,
            'status' => 'pending',
        ]);

        foreach ($cart->items as $item) {
            OrderItem::create([
                'order_id' => $order->id,
                'product_id' => $item->product_id,
                'quantity' => $item->quantity,
                'price' => $item->price,
            ]);
            $product = Product::find($item->product_id);
            $product->quantity -= $item->quantity;
            $product->save();
        }

        // Gửi email xác nhận đơn hàng với mã OTP
        Mail::to(auth()->user()->email)->send(new OrderConfirmation($order));

        // Xóa giỏ hàng sau khi đặt hàng thành công
        $cart->items()->delete();
        $cart->delete();

        return redirect()->route('order.confirmation', ['order' => $order->id]);
    }

    public function showOrderConfirmation(Order $order)
    {
        return view('confirmation', compact('order'));
    }

    public function verifyOtp(Request $request, Order $order)
    {
        $validatedData = $request->validate([
            'otp' => 'required|digits:6',
        ]);

        if ($order->otp == $request->otp) {
            $order->update(['status' => 'completed']);
            return redirect()->route('order-success', ['order' => $order->id]);
        } else {
            return redirect()->route('order.confirmation', ['order' => $order->id])->withErrors(['otp' => 'Mã OTP không chính xác.']);
        }
    }
    public function showOrderSuccess(Order $order)
    {
        return view('order-success', compact('order'));
    }

    public function cancelOrder(Order $order)
    {
        if ($order->status == 'pending') {
            $order->update(['status' => 'canceled']);
        }

        return redirect()->route('order.history')->with('success', 'Đơn hàng đã được hủy.');
    }

    public function showOrderHistory()
    {
        $orders = Order::where('user_id', auth()->id())->get();
        return view('history', compact('orders'));
    }
    public function show(Order $order)
    {
        // Truyền đối tượng đơn hàng vào view để hiển thị chi tiết
        return view('order-details', compact('order'));
    }
}
