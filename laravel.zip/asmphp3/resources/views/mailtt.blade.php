@component('mail::message')
# Xác nhận đơn hàng

Cảm ơn bạn đã đặt hàng. Mã OTP của bạn để xác nhận đơn hàng là: **{{ $order->otp }}**

@component('mail::button', ['url' => route('order.confirmation', ['order' => $order->id])])
Xác nhận đơn hàng
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent