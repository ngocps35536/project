@extends('layout')
@section('tieudetrang')
{{ $ten }}
@endsection
@section('noidung')
<div class="container mt-4">
    <div class="d-flex justify-content-center mb-3">
        @foreach ($data1 as $cat)
        <div class="btn-group me-2" role="group">
            <a href="/cat/{{$cat->id}}" class="btn btn-info">
                {{ $cat->name }}
            </a>
        </div>
        @endforeach
    </div>

    <h2 class="mb-4">Sản phẩm trong loại {{ $ten }}</h2>
    <div class="row">
        @foreach ($data as $sp)
        <div class="col-md-3 mb-3">
            <div class="card h-100">
                <img src="/{{$sp->image}}" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Product Image">
                <div class="card-body">
                    <h6 class="card-title">{{$sp->name}}</h6>
                    <p class="card-text">{{$sp->description}}</p>
                    <p class="card-text highlight-price">Giá: {{ number_format($sp->price, 0, ',', '.') }} VND</p>
                    <div class="mt-auto d-flex justify-content-between align-items-center">
                        <a href="/pro/{{$sp->id}}" class="btn btn-primary btn-custom">Xem chi tiết</a>
                        <form action="{{ route('cart.add') }}" method="POST" class="mb-0">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $sp->id }}">
                            <input type="hidden" name="price" value="{{ $sp->price }}">
                            <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    <div class="d-flex justify-content-center">
        {!! $data->links() !!}
    </div>
</div>




@endsection