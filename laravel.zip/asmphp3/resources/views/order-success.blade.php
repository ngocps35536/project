@extends('layout')

@section('title', 'Xác nhận đơn hàng')

@section('noidung')
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    Xác nhận đơn hàng
                </div>
                <div class="card-body">
                    <p>Mã OTP đã được nhập thành công. Đơn hàng của bạn đã được xác nhận.</p>
                    <p>Cảm ơn bạn đã mua hàng!</p>
                    <a href="{{ route('orders.show', $order) }}" class="btn btn-primary">Xem chi tiết đơn hàng</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection