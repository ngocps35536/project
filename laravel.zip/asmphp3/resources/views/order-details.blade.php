@extends('layout')

@section('title', 'Chi tiết đơn hàng')

@section('noidung')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h2>Chi tiết đơn hàng #{{ $order->id }}</h2>
            <p><strong>Ngày đặt hàng:</strong> {{ $order->created_at }}</p>
            <p><strong>Tổng giá trị đơn hàng:</strong> {{ number_format($order->total_price, 0, ',', '.') }} VND</p>
            <p><strong>Phương thức thanh toán:</strong> {{ $order->payment_method }}</p>
            <hr>
            <h3>Danh sách sản phẩm</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Tên sản phẩm</th>
                        <th>Số lượng</th>
                        <th>Giá</th>
                        <th>Tổng</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($order->items as $item)
                    <tr>
                        <td>{{ $item->product_name }}</td>
                        <td>{{ $item->quantity }}</td>
                        <td>{{ number_format($item->price, 0, ',', '.') }} VND</td>
                        <td>{{ number_format($item->price*$item->quantity, 0, ',', '.') }} VND</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            <hr>
            <h3>Thông tin vận chuyển</h3>
            <p><strong>Địa chỉ giao hàng:</strong> {{ $order->shipping_address }}</p>
            <p><strong>Phí vận chuyển:</strong> {{ number_format($order->shipping_fee, 0, ',', '.') }} VND</p>
        </div>
    </div>
</div>
@endsection