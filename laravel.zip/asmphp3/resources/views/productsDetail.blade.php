@extends('layout')

@section('tieudetrang')
{{ $detail->name }}
@endsection
@section('noidung')
<div class="container mt-4">
    <h2>Chi tiết sản phẩm {{ $detail->name }}</h2>
    <div class="row">
        <div class="col-md-6">
            <img src="/{{ $detail->image }}" class="img-fluid" style="width: 50%; height: 200px; object-fit: cover;" alt="Product Image">
        </div>
        <div class="col-md-6">
            <h4>Tên sản phẩm: {{ $detail->name }}</h4>
            <p>{{ $detail->description }}</p>
            <p>Lượt xem: {{ $detail->view }}</p>
            <p>Còn: {{ $detail->quantity}} sản phẩm</p>
            <h4 class="card-text highlight-price">Giá: {{ number_format($detail->price, 0, ',', '.') }} VND</h4>

            <!-- Thêm input cho số lượng -->
            <form action="{{ route('cart.add') }}" method="POST" class="mb-0">
                @csrf
                <input type="hidden" name="product_id" value="{{ $detail->id }}">
                <input type="hidden" name="price" value="{{ $detail->price }}">
                <label for="quantity">Số lượng:</label>
                <input type="number" id="quantity" name="quantity" value="1" min="1" max="{{ $detail->quantity }}">
                <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
            </form>
            <!-- Kết thúc form -->

        </div>
    </div>
    <hr>
    <!-- Bình luận -->
    <div class="mt-4">
        <h3>Bình luận</h3>
        @if($comments->isEmpty())
        <p>Chưa có bình luận nào.</p>
        @else
        <ul class="list-unstyled">
            @foreach($comments as $comment)
            <li class="mb-2">
                <strong>{{ $comment->hoTen }}</strong>
                ({{ \Carbon\Carbon::parse($comment->created_at)->format('d/m/Y H:i') }})<br>
                {{ $comment->content }}
            </li>
            @endforeach
        </ul>
        @endif
        <!-- Form thêm bình luận -->
        <form action="{{ route('comments.store', $detail->id) }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="content" class="form-label">Bình luận của bạn</label>
                <textarea name="content" id="content" rows="3" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Gửi bình luận</button>
        </form>
    </div>

    <div class="mt-4">
        <h3>Sản phẩm liên quan</h3>
        <div class="row">
            @foreach ($relatedProducts as $sp)
            <div class="col-md-3 mb-3">
                <div class="card h-100">
                    <img src="/{{ $sp->image }}" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Related Product Image">
                    <div class="card-body">
                        <h6 class="card-title">{{ $sp->name }}</h6>
                        <p class="card-text">{{ $sp->description }}</p>
                        <p class="card-text highlight-price">Giá: {{ number_format($sp->price, 0, ',', '.') }} VND</p>
                        <div class="mt-auto d-flex justify-content-between align-items-center">
                            <a href="/pro/{{$sp->id}}" class="btn btn-primary btn-custom">Xem chi tiết</a>
                            <form action="{{ route('cart.add') }}" method="POST" class="mb-0">
                                @csrf
                                <input type="hidden" name="product_id" value="{{ $sp->id }}">
                                <input type="hidden" name="price" value="{{ $sp->price }}">
                                <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>



@endsection