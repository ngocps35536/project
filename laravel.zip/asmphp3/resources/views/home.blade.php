@extends('layout')
@section('tieudetrang')
Trang chủ
@endsection
@section('noidung')
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="{{ asset('img/b1.jpg') }}" class="d-block w-100" alt="..." height="500">
        </div>
        <div class="carousel-item">
            <img src="{{ asset('img/b2.jpg') }}" class="d-block w-100" alt="..." height=500>
        </div>
        <div class="carousel-item">
            <img src="{{ asset('img/b3.jpg') }}" class="d-block w-100" alt="..." height="500">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<div class="container mt-4">
    <h2 class="mb-4">Sản phẩm nổi bật</h2>
    <div class="row">
        @foreach ($sphot as $sp)
        <div class="col-md-3 mb-3">
            <div class="card h-100" style="max-width: 300px;">
                <img src="/{{$sp->image}}" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Product Image">
                <div class="card-body d-flex flex-column">
                    <h6 class="card-title">{{$sp->name}}</h6>
                    <p class="card-text">{{$sp->description}}</p>
                    <p class="card-text highlight-price">Giá: {{ number_format($sp->price, 0, ',', '.') }} VND</p>
                    <div class="mt-auto d-flex justify-content-between align-items-center">
                        <a href="/pro/{{$sp->id}}" class="btn btn-primary btn-custom">Xem chi tiết</a>
                        <form action="{{ route('cart.add') }}" method="POST" class="mb-0">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $sp->id }}">
                            <input type="hidden" name="price" value="{{ $sp->price }}">
                            <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    <hr>
    <h2 class="mb-4">Sản phẩm xem nhiều</h2>
    <div class="row">
        @foreach ($spview as $sp)
        <div class="col-md-3 mb-3">
            <div class="card h-100" style="max-width: 300px;">
                <img src="/{{$sp->image}}" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Product Image">
                <div class="card-body d-flex flex-column">
                    <h6 class="card-title">{{$sp->name}}</h6>
                    <p class="card-text">Lượt xem: {{$sp->view}}</p>
                    <p class="card-text highlight-price">Giá: {{ number_format($sp->price, 0, ',', '.') }} VND</p>
                    <div class="mt-auto d-flex justify-content-between align-items-center">
                        <a href="/pro/{{$sp->id}}" class="btn btn-primary btn-custom">Xem chi tiết</a>
                        <form action="{{ route('cart.add') }}" method="POST" class="mb-0">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $sp->id }}">
                            <input type="hidden" name="price" value="{{ $sp->price }}">
                            <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection

<style>
    .highlight-price {
        color: #FF5733;
        font-weight: bold;
        font-size: 1em;
    }

    .btn-custom {
        flex: 1;
        margin: 0 2px;
    }
</style>