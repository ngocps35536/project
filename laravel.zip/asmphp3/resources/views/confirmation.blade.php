@extends('layout')

@section('tieudetrang')
Xác nhận đơn hàng
@endsection

@section('noidung')
<div class="container mt-4">
    <h2 class="mb-4">Xác nhận đơn hàng</h2>
    <p>Một mã OTP đã được gửi tới email của bạn. Vui lòng nhập mã OTP để xác nhận đơn hàng.</p>
    <form action="{{ route('order.verifyOtp', ['order' => $order->id]) }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="otp" class="form-label">Mã OTP</label>
            <input type="text" class="form-control" id="otp" name="otp" required>
            @error('otp')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <button type="submit" class="btn btn-success">Xác nhận</button>
    </form>
</div>
@endsection