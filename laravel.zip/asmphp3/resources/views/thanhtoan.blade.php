@extends('layout')

@section('tieudetrang')
Thanh toán
@endsection

@section('noidung')
<div class="container mt-4">
    <h2 class="mb-4">Thông tin thanh toán</h2>
    <form action="{{ route('checkout.process') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <h4>Thông tin người dùng</h4>
                <div class="mb-3">
                    <label for="name" class="form-label">Họ tên</label>
                    <input type="text" class="form-control" id="name" name="name" value="{{ $user->hoTen }}" readonly>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="{{ $user->email }}" readonly>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Số điện thoại</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="{{ $user->phone_number }}" readonly>
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Địa chỉ giao hàng</label>
                    <input type="text" class="form-control" id="address" name="address" value="{{ old('address', $user->address) }}" required>
                    @error('address')
                    <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <h4>Thông tin giỏ hàng</h4>
                <div class="mb-3">
                    <label for="voucher" class="form-label">Mã giảm giá</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="voucher" name="voucher" value="{{ old('voucher') }}">
                        <button type="submit" class="btn btn-primary" formaction="{{ route('checkout.applyVoucher') }}">Áp dụng</button>
                    </div>
                    @if($errors->has('voucher'))
                    <div class="text-danger">{{ $errors->first('voucher') }}</div>
                    @endif
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Giá</th>
                            <th>Tổng</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        $totalPrice = 0;
                        $shippingFee = 35000;
                        @endphp
                        @foreach($cart->items as $item)
                        @php
                        $total = $item->price * $item->quantity;
                        $totalPrice += $total;
                        @endphp
                        <tr>
                            <td>{{ $item->product->name }}</td>
                            <td>{{ $item->quantity }}</td>
                            <td>{{ number_format($item->price, 0, ',', '.') }} VND</td>
                            <td>{{ number_format($total, 0, ',', '.') }} VND</td>
                        </tr>
                        @endforeach
                        <tr>
                            <td colspan="3" class="fw-bold">Tổng tiền sản phẩm:</td>
                            <td>{{ number_format($totalPrice, 0, ',', '.') }} VND</td>
                        </tr>
                        <tr>
                            <td colspan="3" class="fw-bold">Phí vận chuyển:</td>
                            <td>{{ number_format($shippingFee, 0, ',', '.') }} VND</td>
                        </tr>
                        <tr>
                            <td colspan="3" class="fw-bold">Tổng cộng:</td>
                            <td>{{ number_format($totalPrice + $shippingFee, 0, ',', '.') }} VND</td>
                        </tr>
                    </tbody>
                </table>
                <h4>Phương thức thanh toán</h4>
                <div class="mb-3">
                    <label for="payment_method" class="form-label">Phương thức thanh toán</label>
                    <select class="form-select" id="payment_method" name="payment_method" required>
                        <option value="credit_card">Thẻ tín dụng</option>
                        <option value="bank_transfer">Chuyển khoản ngân hàng</option>
                        <option value="cash_on_delivery">Thanh toán khi nhận hàng</option>
                    </select>
                    @error('payment_method')
                    <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="text-end">




            <button type="submit" class="btn btn-primary">Tiến hành thanh toán</button>
        </div>
    </form>
</div>
@endsection