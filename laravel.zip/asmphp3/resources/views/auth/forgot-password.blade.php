@extends('layout')

@section('tieudetrang', 'Quên mật khẩu')

@section('noidung')
<div class="container mt-4">
    <h2>Quên mật khẩu</h2>
    @if (session('status'))
    <div class="alert alert-success">
        {{ session('status') }}
    </div>
    @endif
    <form method="POST" action="{{ route('password.email') }}">
        @csrf
        <div class="mb-3">
            <label for="email" class="form-label">Địa chỉ Email</label>
            <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" required>
            @error('email')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Gửi link đặt lại mật khẩu</button>
    </form>
</div>
@endsection