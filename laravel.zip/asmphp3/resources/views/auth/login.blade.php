@extends('layout')

@section('tieudetrang', 'Đăng nhập')

@section('noidung')
@if (session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@endif

@if ($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
<div class="container mt-4">
    <h2>Đăng nhập</h2>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" class="form-control" id="email" name="email" value="{{ old('email') }}" required>
            @error('email')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Mật khẩu</label>
            <input type="password" class="form-control" id="password" name="password" required>
            @error('password')
            <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="mb-3">
            <a href="{{ route('password.request') }}">Quên mật khẩu?</a>
        </div>
        <button type="submit" class="btn btn-primary">Đăng nhập</button>
    </form>
    <div id="dngooggle" class="text-center">
        <a href="http://localhost:8000/login/google">
            <img width="300" src="https://developers.google.com/identity/images/btn_google_signin_dark_normal_web.png">
        </a>
    </div>

</div>

@endsection