@extends('layout')

@section('tieudetrang')
Lịch sử đơn hàng
@endsection

@section('noidung')
<div class="container mt-4">
    <h2 class="mb-4">Lịch sử đơn hàng</h2>
    @if($orders->isNotEmpty())
    <table class="table">
        <thead>
            <tr>
                <th>Mã đơn hàng</th>
                <th>Ngày đặt</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
            <tr>
                <td>{{ $order->id }}</td>
                <td>{{ $order->created_at->format('d/m/Y H:i') }}</td>
                <td>{{ number_format($order->total_price, 0, ',', '.') }} VND</td>
                <td>{{ $order->status }}</td>
                <td>
                    @if($order->status == 'pending')
                    <form action="{{ route('order.cancel', ['order' => $order->id]) }}" method="POST" style="display: inline-block;">
                        @csrf
                        <button type="submit" class="btn btn-danger btn-sm">Hủy đơn hàng</button>
                    </form>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <p>Bạn chưa có đơn hàng nào.</p>
    @endif
</div>
@endsection