@extends('admin.dashboard')

@section('content')
<div class="container">
    <h1>Chi tiết đơn hàng</h1>
    <p>ID: {{ $order->id }}</p>
    <p>Người dùng: {{ $order->user->name }}</p>
    <p>Địa chỉ: {{ $order->address }}</p>
    <p>Phương thức thanh toán: {{ $order->payment_method }}</p>
    <p>Tổng giá: {{ $order->total_price }}</p>
    <p>Trạng thái: {{ $order->status }}</p>
</div>
@endsection