@extends('admin.dashboard')

@section('content')
<div class="container">
    <h1>Chỉnh sửa danh mục</h1>

    <form action="{{ route('categories.update', $category->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="name">Tên danh mục</label>
            <input type="text" name="name" class="form-control" id="name" value="{{ $category->name }}" required>
        </div>
        <div class="form-group">
            <label for="anHien">Ẩn/Hiện</label>
            <select name="anHien" id="anHien" class="form-control">
                <option value="1" {{ $category->anHien ? 'selected' : '' }}>Hiện</option>
                <option value="0" {{ !$category->anHien ? 'selected' : '' }}>Ẩn</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
</div>
@endsection