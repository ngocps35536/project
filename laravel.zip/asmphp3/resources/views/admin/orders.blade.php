@extends('admin.dashboard')

@section('content')
<div class="container">
    <h1>Danh sách đơn hàng</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Người dùng</th>
                <th>Địa chỉ</th>
                <th>Phương thức thanh toán</th>
                <th>Tổng giá</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            @foreach($orders as $order)
            <tr>
                <td>{{ $order->id }}</td>
                <td>{{ $order->user->hoTen }}</td>
                <td>{{ $order->address }}</td>
                <td>{{ $order->payment_method }}</td>
                <td>{{ $order->total_price }}</td>
                <td>{{ $order->status }}</td>
                <td>
                    <a href="{{ route('admin.orders.show', $order->id) }}" class="btn btn-primary">Xem chi tiết</a>
                    <a href="{{ route('admin.orders.edit', $order->id) }}" class="btn btn-secondary">Sửa</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
{{ $orders->links() }}
@endsection