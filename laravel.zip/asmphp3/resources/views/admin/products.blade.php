<!-- resources/views/admin/products.blade.php -->
@extends('admin.dashboard')

@section('content')
<div class="section-header d-flex justify-content-between align-items-center mb-3">
    <h2>Quản lý Products</h2>
    <a href="/admin/products/create" class="btn btn-success">Thêm sản phẩm</a>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Hình ảnh</th>
            <th>Giá</th>
            <th>Số lượng</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($products as $product)
        <tr>
            <td>{{ $product->id }}</td>
            <td>{{ $product->name }}</td>
            <td><img src="/{{$product->image}}" style="width: 50px; height: 50px;"></td>
            <td>{{ $product->price }}</td>
            <td>{{ $product->quantity }}</td>
            <td>
                @if($product->trashed())
                <form action="{{ route('admin.products.restore', $product->id) }}" method="POST" style="display:inline;">
                    @csrf
                    <button type="submit" class="btn btn-warning btn-sm">Khôi phục</button>
                </form>
                <form action="{{ route('admin.products.forceDelete', $product->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này vĩnh viễn?')">Xóa vĩnh
                        viễn</button>
                </form>
                @else
                <a href="{{ route('admin.products.edit', $product->id) }}" class="btn btn-primary btn-sm">Sửa</a>
                <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')">Xóa</button>
                </form>
                @endif

            </td>
            </t r>
            @endforeach
    </tbody>
</table>
{{ $products->links() }}
@endsection