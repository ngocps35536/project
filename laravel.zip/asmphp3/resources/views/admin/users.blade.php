<!-- resources/views/admin/users/index.blade.php -->
@extends('admin.dashboard')

@section('content')
<div id="users" class="section-header">
    <h2>Quản lý Users</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Họ tên</th>
                <th>Email</th>
                <th>Vai trò</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)
            <tr>
                <td>{{ $user->id }}</td>
                <td>{{ $user->hoTen }}</td>
                <td>{{ $user->email }}</td>
                <td>{{ $user->role }}</td>
                <td>{{ $user->status }}</td>
                <td>
                    <a href="/admin/users/{{$user->id}}/edit" class="btn btn-primary btn-sm">Sửa</a>
                    <form action="{{ route('admin.users.toggle-status', $user->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('PUT')
                        <button type="submit" class="btn btn-warning btn-sm">Mở/Khóa</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection