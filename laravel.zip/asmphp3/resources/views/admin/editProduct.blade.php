@extends('admin.dashboard')

@section('content')
<div class="section-header">
    <h2>Cập nhật sản phẩm</h2>
</div>

<form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <div class="mb-3">
        <label for="name" class="form-label">Tên sản phẩm</label>
        <input type="text" class="form-control" id="name" name="name" value="{{ $product->name }}" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Mô tả</label>
        <textarea class="form-control" id="description" name="description" rows="3" required>{{ $product->description }}</textarea>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Giá</label>
        <input type="number" class="form-control" id="price" name="price" step="0.01" value="{{ $product->price }}" required>
    </div>
    <div class="mb-3">
        <label for="sale" class="form-label">Giảm giá (%)</label>
        <select class="form-select" id="sale" name="sale" required>
            <option value="0" {{ $product->sale == '0' ? 'selected' : '' }}>0%</option>
            <option value="10" {{ $product->sale == '10' ? 'selected' : '' }}>10%</option>
            <option value="15" {{ $product->sale == '15' ? 'selected' : '' }}>15%</option>
            <option value="20" {{ $product->sale == '20' ? 'selected' : '' }}>20%</option>
            <option value="25" {{ $product->sale == '25' ? 'selected' : '' }}>25%</option>
        </select>
    </div>
    <div class="mb-3">
        <label for="quantity" class="form-label">Số lượng</label>
        <input type="number" class="form-control" id="quantity" name="quantity" value="{{ $product->quantity }}" required>
    </div>
    <div class="mb-3">
        <label for="image" class="form-label">Hình ảnh</label>
        <input type="file" class="form-control" id="image" name="image">
        @if($product->image)
        <img src="/{{ $product->image }}" style="width: 100px; height: 100px;" class="mt-2">
        @endif
    </div>
    <div class="mb-3">
        <label for="idCat" class="form-label">Danh mục</label>
        <select class="form-select" id="idCat" name="idCat" required>
            @foreach($categories as $category)
            <option value="{{ $category->id }}" {{ $product->idCat == $category->id ? 'selected' : '' }}>
                {{ $category->name }}
            </option>
            @endforeach
        </select>
    </div>
    <button type="submit" class="btn btn-primary">Cập nhật sản phẩm</button>
</form>
@endsection