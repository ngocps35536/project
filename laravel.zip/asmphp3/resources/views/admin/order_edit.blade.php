@extends('admin.dashboard')

@section('content')
<div class="container">
    <h1>Chỉnh sửa đơn hàng #{{ $order->id }}</h1>
    <form method="POST" action="{{ route('admin.orders.update', $order->id) }}">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="address" class="form-label">Địa chỉ:</label>
            <input type="text" class="form-control" name="address" id="address" value="{{ $order->address }}">
        </div>
        <div class="mb-3">
            <label for="payment_method" class="form-label">Phương thức thanh toán:</label>
            <input type="text" class="form-control" name="payment_method" id="payment_method" value="{{ $order->payment_method }}">
        </div>
        <div class="mb-3">
            <label for="status" class="form-label">Trạng thái:</label>
            <select class="form-select" name="status" id="status">
                <option value="pending" {{ $order->status == 'pending' ? 'selected' : '' }}>Pending</option>
                <option value="completed" {{ $order->status == 'completed' ? 'selected' : '' }}>Completed</option>
                <option value="canceled" {{ $order->status == 'canceled' ? 'selected' : '' }}>Canceled</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Lưu</button>
    </form>
</div>

@endsection