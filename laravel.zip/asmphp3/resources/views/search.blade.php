@extends('layout')
@section('tieudetrang')
Tìm kiếm
@endsection
@section('noidung')
<div class="container mt-4">
    <h2 class="mb-4">Kết quả tìm kiếm với từ khóa {{ $query }}</h2>
    <div class="row">
        @foreach ($products as $sp)
        <div class="col-md-3 mb-3">
            <div class="card h-100">
                <img src="/{{$sp->image}}" class="card-img-top img-fluid"
                    style="width: 100%; height: 200px; object-fit: cover;" alt="Product Image">
                <div class="card-body">
                    <h6 class="card-title">{{$sp->name}}</h6>
                    <p class="card-text">{{$sp->description}}</p>
                    <p class="card-text">Giá: {{$sp->price}}</p>
                    <form action="{{ route('cart.add') }}" method="POST" class="mb-0">
                        @csrf
                        <input type="hidden" name="product_id" value="{{ $sp->id }}">
                        <input type="hidden" name="price" value="{{ $sp->price }}">
                        <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>


@endsection