<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>
    <div class="container text-center">
        <h1>404</h1>
        <h2>Trang không tìm thấy</h2>
        <p>Xin lỗi, trang bạn đang tìm kiếm không tồn tại.</p>
        <a href="/" class="btn btn-primary">Quay lại trang chủ</a>
    </div>
</body>

</html>