<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class insertCategory extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('categories')->truncate();
        $categories = [
            ['name' => 'Ngũ cốc', 'anHien' => 1],
            ['name' => 'Sữa', 'anHien' => 1],
            ['name' => 'Trái cây', 'anHien' => 1],
            ['name' => 'Nước ép', 'anHien' => 1]
        ];

        foreach ($categories as $category) {
            DB::table('categories')->insert([
                'name' => $category['name'],
                'slug' => Str::slug($category['name']),
                'anHien' => $category['anHien']
            ]);
        }
    }
}
