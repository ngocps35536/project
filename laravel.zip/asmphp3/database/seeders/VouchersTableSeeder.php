<?php
// database/seeders/VouchersTableSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class VouchersTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('vouchers')->insert([
            [
                'code' => 'FREESHIP',
                'type' => 'shipping',
                'value' => 35000, // 35k giảm phí vận chuyển
                'expiration_date' => Carbon::now()->addMonth(),
                'usage_limit' => 50, // Giới hạn 50 lần
                'times_used' => 0,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'code' => 'DISCOUNT10',
                'type' => 'percentage',
                'value' => 10, // 10% giảm giá
                'expiration_date' => Carbon::now()->addMonth(),
                'usage_limit' => 100, // Giới hạn 100 lần
                'times_used' => 0,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
            [
                'code' => 'DISCOUNT50K',
                'type' => 'fixed',
                'value' => 50000, // Giảm 50k
                'expiration_date' => Carbon::now()->addMonth(),
                'usage_limit' => 30, // Giới hạn 30 lần
                'times_used' => 0,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ],
        ]);
    }
}