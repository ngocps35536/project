<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;

class insertProducts extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $sales = ['0', '10', '15', '20', '25'];
        $ten = ['Tươi', 'Lạnh', 'Dinh Dưỡng', 'Ngon', 'Mát'];
        $size = ['Lớn', 'Vừa', 'Nhỏ'];
        for ($i = 0; $i < 30; $i++) {
            $s = Arr::random($size);
            $ht = Arr::random($ten);
            DB::table('products')->insert([
                ['name' => 'Sữa ' . $ht . ' ' . $s, 'price' => mt_rand(70000, 100000), 'quantity' => mt_rand(100, 300), 'image' => 'img/' . mt_rand(60, 69) . '.jpg', 'idCat' => 2, 'sale' => $sales[array_rand($sales)], 'description' => 'Mô tả sản phẩm', 'view' => mt_rand(0, 100)],
                ['name' => 'Set Trái Cây ' . $ht . ' ' . $s, 'price' => mt_rand(50000, 80000), 'quantity' => mt_rand(100, 300), 'image' => 'img/' . mt_rand(40, 55) . '.jpg', 'idCat' => 3, 'sale' => $sales[array_rand($sales)], 'description' => 'Mô tả sản phẩm', 'view' => mt_rand(0, 100)],
                ['name' => 'Ngũ Cốc ' . $ht . ' ' . $s, 'price' => mt_rand(60000, 750000), 'quantity' => mt_rand(100, 300), 'image' => 'img/' . mt_rand(1, 19) . '.jpg', 'idCat' => 1, 'sale' => $sales[array_rand($sales)], 'description' => 'Mô tả sản phẩm', 'view' => mt_rand(0, 100)],
                ['name' => 'Nước Trái Cây ' . $ht . ' ' . $s, 'price' => mt_rand(25000, 50000), 'quantity' => mt_rand(100, 300), 'image' => 'img/' . mt_rand(21, 35) . '.jpg', 'idCat' => 4, 'sale' => $sales[array_rand($sales)], 'description' => 'Mô tả sản phẩm', 'view' => mt_rand(0, 100)],
            ]);
        }
    }
}
