-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th6 10, 2024 lúc 09:53 AM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `asmphp3`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(2, 2, 'active', '2024-05-23 06:21:38', '2024-05-23 06:21:38'),
(3, 3, 'active', '2024-05-24 00:21:18', '2024-05-24 00:21:18'),
(4, 4, 'active', '2024-06-02 00:24:46', '2024-06-02 00:24:46'),
(5, 7, 'active', '2024-06-04 03:59:47', '2024-06-04 03:59:47'),
(23, 11, 'active', '2024-06-08 22:55:51', '2024-06-08 22:55:51'),
(28, 13, 'active', '2024-06-09 22:35:17', '2024-06-09 22:35:17'),
(29, 1, 'active', '2024-06-10 00:13:37', '2024-06-10 00:13:37');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart_items`
--

CREATE TABLE `cart_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cart_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `cart_items`
--

INSERT INTO `cart_items` (`id`, `cart_id`, `product_id`, `quantity`, `price`, `created_at`, `updated_at`) VALUES
(2, 2, 75, 1, 699191.00, '2024-05-23 06:21:38', '2024-05-23 06:21:38'),
(3, 2, 111, 4, 431419.00, '2024-05-23 06:22:00', '2024-05-23 06:31:40'),
(4, 2, 118, 1, 52593.00, '2024-05-23 06:54:47', '2024-05-23 06:54:47'),
(5, 2, 88, 1, 42526.00, '2024-05-23 07:25:48', '2024-05-23 07:25:48'),
(6, 3, 88, 1, 42526.00, '2024-05-24 00:21:18', '2024-05-24 00:21:18'),
(7, 3, 118, 1, 52593.00, '2024-05-24 00:21:22', '2024-05-24 00:21:22'),
(8, 3, 90, 1, 58007.00, '2024-05-24 00:21:28', '2024-05-24 00:21:28'),
(9, 4, 111, 1, 431419.00, '2024-06-02 00:24:46', '2024-06-02 00:24:46'),
(10, 4, 72, 2, 33374.00, '2024-06-02 00:25:10', '2024-06-02 00:25:10'),
(11, 4, 122, 1, 78197.00, '2024-06-02 00:25:14', '2024-06-02 00:25:14'),
(20, 5, 118, 2, 52593.00, '2024-06-04 03:59:47', '2024-06-04 04:20:11'),
(22, 5, 111, 8, 431419.00, '2024-06-04 04:06:54', '2024-06-04 04:20:21'),
(50, 23, 72, 1, 33374.00, '2024-06-08 22:55:51', '2024-06-08 22:55:51'),
(51, 23, 90, 3, 58007.00, '2024-06-08 22:55:55', '2024-06-08 22:56:01'),
(59, 28, 108, 1, 38445.00, '2024-06-09 22:35:17', '2024-06-09 22:35:17'),
(60, 29, 111, 1, 431419.00, '2024-06-10 00:13:37', '2024-06-10 00:23:59');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `anHien` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `anHien`, `created_at`, `updated_at`) VALUES
(1, 'Ngũ cốc 7', 'ngu-coc-7', 1, NULL, '2024-06-09 20:35:51'),
(2, 'Sữa ', 'sua', 1, NULL, NULL),
(3, 'Trái cây', 'trai-cay', 1, NULL, NULL),
(4, 'Nước ép', 'nuoc-ep', 1, NULL, NULL),
(11, 'Quản Trị Viên 2', 'quan-tri-vien-2', 1, '2024-06-09 20:36:02', '2024-06-09 20:36:02');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `comments`
--

INSERT INTO `comments` (`id`, `content`, `product_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Sản phẩm tốt', 118, 1, '2024-06-04 20:54:28', '2024-06-04 20:54:28'),
(2, 'Bạn có thể giảm giá cho mình chút được không', 23, 1, '2024-06-04 20:55:57', '2024-06-04 20:55:57'),
(3, 'Bạn có thể giám giá cho mình chút đc ko', 87, 1, '2024-06-04 21:17:39', '2024-06-04 21:17:39'),
(4, 'good', 121, 1, '2024-06-07 23:01:23', '2024-06-07 23:01:23'),
(5, 'chán', 121, 1, '2024-06-09 02:44:09', '2024-06-09 02:44:09'),
(6, 'chán', 121, 1, '2024-06-09 02:44:09', '2024-06-09 02:44:09'),
(7, 'alo', 121, 1, '2024-06-09 02:44:17', '2024-06-09 02:44:17'),
(8, 'sản phẩm tốt', 111, 14, '2024-06-10 00:40:08', '2024-06-10 00:40:08');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_05_22_120421_tao_table_categories', 2),
(5, '2024_05_22_120550_tao_table_products', 3),
(6, '2024_05_22_121016_tao_table_users', 4),
(7, '2024_05_22_121154_tao_table_carts', 5),
(8, '2024_05_22_121416_tao_table_cart_items', 6),
(9, '2024_06_03_033716_add_deleted_at_to_products_table', 7),
(10, '2024_06_04_115311_tao_vouchers', 8),
(11, '2024_06_04_120536_add_used_at_to_vouchers_table', 9),
(12, '2024_06_04_184249_create_orders_table', 10),
(13, '2024_06_04_184440_create_order_items_table', 11),
(14, '2024_06_05_031951_create_comments_table', 12),
(15, '2024_06_09_052052_create_vouchers_table', 13),
(16, '2024_06_10_050421_them_google_i_d', 14);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `address` varchar(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `status` enum('pending','completed','canceled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address`, `payment_method`, `total_price`, `otp`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Quỳnh Thanh', 'credit_card', 2191317.00, '716672', 'canceled', '2024-06-04 12:02:51', '2024-06-04 12:05:10'),
(2, 1, 'Quỳnh Thanh', 'credit_card', 431419.00, '499208', 'pending', '2024-06-04 12:06:44', '2024-06-04 12:06:44'),
(3, 1, 'Quỳnh Thanh', 'cash_on_delivery', 1950570.00, '481119', 'pending', '2024-06-04 12:17:36', '2024-06-04 12:17:36'),
(4, 1, 'Quỳnh Thanh', 'credit_card', 3504314.00, '187835', 'pending', '2024-06-04 12:20:42', '2024-06-04 12:20:42'),
(5, 1, 'Quỳnh Thanh', 'credit_card', 277388.00, '422890', 'pending', '2024-06-04 12:21:47', '2024-06-04 12:21:47'),
(6, 1, 'Quỳnh Thanh', 'credit_card', 277388.00, '915122', 'completed', '2024-06-04 12:24:24', '2024-06-04 12:24:47'),
(7, 1, 'Quỳnh Thanh', 'credit_card', 42526.00, '758475', 'completed', '2024-06-04 12:35:08', '2024-06-04 12:35:42'),
(8, 1, 'Quỳnh Thanh', 'credit_card', 83430.00, '959225', 'completed', '2024-06-04 12:48:10', '2024-06-04 12:48:42'),
(9, 1, 'Quỳnh Thanh', 'credit_card', 528710.00, '369204', 'completed', '2024-06-04 12:50:33', '2024-06-04 12:50:50'),
(11, 1, 'Quỳnh Thanh', 'credit_card', 105186.00, '788646', 'completed', '2024-06-05 00:11:44', '2024-06-05 00:12:19'),
(12, 1, 'Quỳnh Thanh', 'credit_card', 52593.00, '228996', 'pending', '2024-06-07 21:42:26', '2024-06-07 21:42:26'),
(13, 1, 'Quỳnh Thanh', 'credit_card', 803463.00, '149558', 'completed', '2024-06-07 22:58:40', '2024-06-07 22:59:07'),
(14, 10, 'Quận Tân Bình', 'credit_card', 1009942.00, '612118', 'canceled', '2024-06-08 19:38:08', '2024-06-08 19:38:34'),
(17, 1, 'Quỳnh Thanh', 'credit_card', 431419.00, '928761', 'completed', '2024-06-08 22:38:32', '2024-06-08 22:39:16'),
(18, 1, 'Quỳnh Thanh', 'credit_card', 241209.00, '402245', 'completed', '2024-06-09 02:44:41', '2024-06-09 02:45:10'),
(19, 12, 'Quỳnh Thanh', 'credit_card', 386313.00, '179629', 'completed', '2024-06-09 04:48:49', '2024-06-09 04:50:07'),
(20, 12, 'Hà Nội', 'credit_card', 52593.00, '354163', 'canceled', '2024-06-09 04:56:39', '2024-06-09 07:02:57'),
(21, 14, 'HCM', 'bank_transfer', 431419.00, '866673', 'pending', '2024-06-09 22:27:31', '2024-06-09 22:27:31'),
(22, 14, 'Đà Nẵng', 'credit_card', 1075642.00, '865283', 'completed', '2024-06-09 22:28:34', '2024-06-09 22:36:48'),
(23, 14, '0954389', 'credit_card', 4314190.00, '588277', 'completed', '2024-06-10 00:38:49', '2024-06-10 00:39:41');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, 75, 1, 699191.00, '2024-06-04 12:02:51', '2024-06-04 12:02:51'),
(2, 1, 118, 2, 52593.00, '2024-06-04 12:02:51', '2024-06-04 12:02:51'),
(3, 1, 23, 5, 277388.00, '2024-06-04 12:02:51', '2024-06-04 12:02:51'),
(4, 2, 111, 1, 431419.00, '2024-06-04 12:06:44', '2024-06-04 12:06:44'),
(5, 3, 118, 1, 52593.00, '2024-06-04 12:17:36', '2024-06-04 12:17:36'),
(6, 3, 23, 3, 277388.00, '2024-06-04 12:17:36', '2024-06-04 12:17:36'),
(7, 3, 91, 7, 152259.00, '2024-06-04 12:17:36', '2024-06-04 12:17:36'),
(8, 4, 23, 1, 277388.00, '2024-06-04 12:20:42', '2024-06-04 12:20:42'),
(9, 4, 87, 3, 376451.00, '2024-06-04 12:20:42', '2024-06-04 12:20:42'),
(10, 4, 75, 3, 699191.00, '2024-06-04 12:20:42', '2024-06-04 12:20:42'),
(11, 5, 23, 1, 277388.00, '2024-06-04 12:21:47', '2024-06-04 12:21:47'),
(12, 6, 23, 1, 277388.00, '2024-06-04 12:24:24', '2024-06-04 12:24:24'),
(13, 7, 88, 1, 42526.00, '2024-06-04 12:35:08', '2024-06-04 12:35:08'),
(14, 8, 121, 1, 83430.00, '2024-06-04 12:48:10', '2024-06-04 12:48:10'),
(15, 9, 91, 1, 152259.00, '2024-06-04 12:50:33', '2024-06-04 12:50:33'),
(16, 9, 87, 1, 376451.00, '2024-06-04 12:50:33', '2024-06-04 12:50:33'),
(18, 11, 118, 2, 52593.00, '2024-06-05 00:11:44', '2024-06-05 00:11:44'),
(19, 12, 118, 1, 52593.00, '2024-06-07 21:42:26', '2024-06-07 21:42:26'),
(20, 13, 118, 1, 52593.00, '2024-06-07 22:58:40', '2024-06-07 22:58:40'),
(21, 13, 121, 9, 83430.00, '2024-06-07 22:58:40', '2024-06-07 22:58:40'),
(22, 14, 111, 1, 431419.00, '2024-06-08 19:38:08', '2024-06-08 19:38:08'),
(23, 14, 118, 11, 52593.00, '2024-06-08 19:38:08', '2024-06-08 19:38:08'),
(27, 17, 111, 1, 431419.00, '2024-06-08 22:38:32', '2024-06-08 22:38:32'),
(28, 18, 118, 3, 52593.00, '2024-06-09 02:44:41', '2024-06-09 02:44:41'),
(29, 18, 121, 1, 83430.00, '2024-06-09 02:44:41', '2024-06-09 02:44:41'),
(30, 19, 118, 1, 52593.00, '2024-06-09 04:48:49', '2024-06-09 04:48:49'),
(31, 19, 121, 4, 83430.00, '2024-06-09 04:48:49', '2024-06-09 04:48:49'),
(32, 20, 118, 1, 52593.00, '2024-06-09 04:56:39', '2024-06-09 04:56:39'),
(33, 21, 111, 1, 431419.00, '2024-06-09 22:27:31', '2024-06-09 22:27:31'),
(34, 22, 75, 1, 699191.00, '2024-06-09 22:28:34', '2024-06-09 22:28:34'),
(35, 22, 87, 1, 376451.00, '2024-06-09 22:28:34', '2024-06-09 22:28:34'),
(36, 23, 111, 10, 431419.00, '2024-06-10 00:38:49', '2024-06-10 00:38:49');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('dcuong2009@gmail.com', '$2y$12$OjBJtPirc4/J7LNc7CmhTeglNenZRptippvlp/HLKtHFCDEPxFyNG', '2024-06-02 01:14:16');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `sale` enum('0','10','15','20','25') NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `view` int(11) NOT NULL,
  `idCat` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `description`, `price`, `sale`, `quantity`, `image`, `view`, `idCat`, `created_at`, `updated_at`, `deleted_at`) VALUES
(5, 'Sữa Tươi Lớn', '', 'Mô tả sản phẩm', 91905.00, '15', 296, 'img/64.jpg', 46, 2, NULL, NULL, NULL),
(6, 'Set Trái Cây Tươi Lớn', '', 'Mô tả sản phẩm', 72422.00, '25', 140, 'img/42.jpg', 86, 3, NULL, NULL, NULL),
(7, 'Ngũ Cốc Tươi Lớn', '', 'Mô tả sản phẩm', 588945.00, '10', 205, 'img/4.jpg', 9, 1, NULL, NULL, NULL),
(8, 'Nước Trái Cây Tươi Lớn', '', 'Mô tả sản phẩm', 30444.00, '15', 144, 'img/34.jpg', 54, 4, NULL, NULL, NULL),
(9, 'Sữa Tươi Vừa', '', 'Mô tả sản phẩm', 79130.00, '20', 118, 'img/64.jpg', 34, 2, NULL, NULL, NULL),
(10, 'Set Trái Cây Tươi Vừa', '', 'Mô tả sản phẩm', 78962.00, '0', 136, 'img/48.jpg', 51, 3, NULL, NULL, NULL),
(11, 'Ngũ Cốc Tươi Vừa', '', 'Mô tả sản phẩm', 392374.00, '10', 216, 'img/14.jpg', 62, 1, NULL, NULL, NULL),
(12, 'Nước Trái Cây Tươi Vừa', '', 'Mô tả sản phẩm', 34219.00, '15', 250, 'img/32.jpg', 76, 4, NULL, NULL, NULL),
(13, 'Sữa Mát Nhỏ', '', 'Mô tả sản phẩm', 89313.00, '10', 173, 'img/69.jpg', 8, 2, NULL, NULL, NULL),
(14, 'Set Trái Cây Mát Nhỏ', '', 'Mô tả sản phẩm', 74024.00, '0', 284, 'img/43.jpg', 66, 3, NULL, NULL, NULL),
(15, 'Ngũ Cốc Mát Nhỏ', '', 'Mô tả sản phẩm', 725198.00, '25', 279, 'img/4.jpg', 45, 1, NULL, NULL, NULL),
(16, 'Nước Trái Cây Mát Nhỏ', '', 'Mô tả sản phẩm', 48494.00, '20', 189, 'img/24.jpg', 52, 4, NULL, NULL, NULL),
(17, 'Sữa Mát Vừa', '', 'Mô tả sản phẩm', 90322.00, '20', 276, 'img/64.jpg', 18, 2, NULL, NULL, NULL),
(18, 'Set Trái Cây Mát Vừa', '', 'Mô tả sản phẩm', 65447.00, '10', 256, 'img/40.jpg', 61, 3, NULL, NULL, NULL),
(19, 'Ngũ Cốc Mát Vừa', '', 'Mô tả sản phẩm', 494000.00, '25', 111, 'img/15.jpg', 39, 1, NULL, NULL, NULL),
(20, 'Nước Trái Cây Mát Vừa', '', 'Mô tả sản phẩm', 25913.00, '10', 173, 'img/31.jpg', 21, 4, NULL, NULL, NULL),
(21, 'Sữa Ngon Nhỏ', '', 'Mô tả sản phẩm', 92285.00, '0', 108, 'img/64.jpg', 54, 2, NULL, NULL, NULL),
(22, 'Set Trái Cây Ngon Nhỏ', '', 'Mô tả sản phẩm', 64261.00, '20', 106, 'img/44.jpg', 40, 3, NULL, NULL, NULL),
(23, 'Ngũ Cốc Ngon Nhỏ', '', 'Mô tả sản phẩm', 277388.00, '0', 59, 'img/10.jpg', 104, 1, NULL, '2024-06-08 19:41:37', NULL),
(24, 'Nước Trái Cây Ngon Nhỏ', '', 'Mô tả sản phẩm', 43872.00, '25', 142, 'img/34.jpg', 101, 4, NULL, NULL, NULL),
(25, 'Sữa Mát Nhỏ', '', 'Mô tả sản phẩm', 89365.00, '25', 183, 'img/67.jpg', 48, 2, NULL, NULL, NULL),
(26, 'Set Trái Cây Mát Nhỏ', '', 'Mô tả sản phẩm', 68414.00, '25', 125, 'img/44.jpg', 68, 3, NULL, NULL, NULL),
(27, 'Ngũ Cốc Mát Nhỏ', '', 'Mô tả sản phẩm', 412404.00, '20', 181, 'img/10.jpg', 78, 1, NULL, NULL, NULL),
(28, 'Nước Trái Cây Mát Nhỏ', '', 'Mô tả sản phẩm', 44629.00, '25', 169, 'img/28.jpg', 75, 4, NULL, NULL, NULL),
(29, 'Sữa Mát Lớn', '', 'Mô tả sản phẩm', 78018.00, '0', 110, 'img/63.jpg', 22, 2, NULL, NULL, NULL),
(30, 'Set Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 52361.00, '20', 290, 'img/50.jpg', 87, 3, NULL, NULL, NULL),
(31, 'Ngũ Cốc Mát Lớn', '', 'Mô tả sản phẩm', 348540.00, '15', 299, 'img/10.jpg', 11, 1, NULL, NULL, NULL),
(32, 'Nước Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 34577.00, '20', 144, 'img/27.jpg', 98, 4, NULL, NULL, NULL),
(33, 'Sữa Mát Lớn', '', 'Mô tả sản phẩm', 72290.00, '15', 300, 'img/68.jpg', 25, 2, NULL, NULL, NULL),
(34, 'Set Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 73335.00, '20', 180, 'img/50.jpg', 7, 3, NULL, NULL, NULL),
(35, 'Ngũ Cốc Mát Lớn', '', 'Mô tả sản phẩm', 288760.00, '20', 165, 'img/15.jpg', 0, 1, NULL, NULL, NULL),
(36, 'Nước Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 33928.00, '0', 113, 'img/30.jpg', 20, 4, NULL, NULL, NULL),
(37, 'Sữa Lạnh Lớn', '', 'Mô tả sản phẩm', 96390.00, '10', 143, 'img/67.jpg', 50, 2, NULL, NULL, NULL),
(38, 'Set Trái Cây Lạnh Lớn', '', 'Mô tả sản phẩm', 55146.00, '15', 220, 'img/46.jpg', 27, 3, NULL, NULL, NULL),
(39, 'Ngũ Cốc Lạnh Lớn', '', 'Mô tả sản phẩm', 641107.00, '10', 271, 'img/10.jpg', 61, 1, NULL, NULL, NULL),
(40, 'Nước Trái Cây Lạnh Lớn', '', 'Mô tả sản phẩm', 36022.00, '0', 101, 'img/29.jpg', 36, 4, NULL, NULL, NULL),
(41, 'Sữa Ngon Vừa', '', 'Mô tả sản phẩm', 70937.00, '20', 123, 'img/68.jpg', 74, 2, NULL, NULL, NULL),
(42, 'Set Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 70491.00, '15', 150, 'img/49.jpg', 72, 3, NULL, NULL, NULL),
(43, 'Ngũ Cốc Ngon Vừa', '', 'Mô tả sản phẩm', 312137.00, '15', 201, 'img/5.jpg', 53, 1, NULL, NULL, NULL),
(44, 'Nước Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 32904.00, '25', 139, 'img/22.jpg', 89, 4, NULL, NULL, NULL),
(45, 'Sữa Lạnh Nhỏ', '', 'Mô tả sản phẩm', 95079.00, '25', 273, 'img/64.jpg', 51, 2, NULL, NULL, NULL),
(46, 'Set Trái Cây Lạnh Nhỏ', '', 'Mô tả sản phẩm', 72993.00, '10', 226, 'img/50.jpg', 90, 3, NULL, NULL, NULL),
(47, 'Ngũ Cốc Lạnh Nhỏ', '', 'Mô tả sản phẩm', 312992.00, '15', 256, 'img/2.jpg', 36, 1, NULL, NULL, NULL),
(48, 'Nước Trái Cây Lạnh Nhỏ', '', 'Mô tả sản phẩm', 43976.00, '0', 112, 'img/22.jpg', 0, 4, NULL, NULL, NULL),
(49, 'Sữa Mát Lớn', '', 'Mô tả sản phẩm', 99405.00, '10', 186, 'img/66.jpg', 88, 2, NULL, NULL, NULL),
(50, 'Set Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 77869.00, '25', 137, 'img/46.jpg', 39, 3, NULL, NULL, NULL),
(51, 'Ngũ Cốc Mát Lớn', '', 'Mô tả sản phẩm', 609205.00, '0', 199, 'img/15.jpg', 74, 1, NULL, NULL, NULL),
(52, 'Nước Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 29115.00, '0', 168, 'img/21.jpg', 100, 4, NULL, NULL, NULL),
(53, 'Sữa Ngon Nhỏ', '', 'Mô tả sản phẩm', 74216.00, '25', 246, 'img/69.jpg', 76, 2, NULL, NULL, NULL),
(54, 'Set Trái Cây Ngon Nhỏ', '', 'Mô tả sản phẩm', 53565.00, '0', 283, 'img/50.jpg', 45, 3, NULL, NULL, NULL),
(55, 'Ngũ Cốc Ngon Nhỏ', '', 'Mô tả sản phẩm', 297926.00, '10', 155, 'img/9.jpg', 83, 1, NULL, NULL, NULL),
(56, 'Nước Trái Cây Ngon Nhỏ', '', 'Mô tả sản phẩm', 38164.00, '20', 148, 'img/25.jpg', 60, 4, NULL, NULL, NULL),
(57, 'Sữa Mát Vừa', '', 'Mô tả sản phẩm', 85131.00, '10', 282, 'img/68.jpg', 10, 2, NULL, NULL, NULL),
(58, 'Set Trái Cây Mát Vừa', '', 'Mô tả sản phẩm', 54869.00, '20', 224, 'img/49.jpg', 54, 3, NULL, NULL, NULL),
(59, 'Ngũ Cốc Mát Vừa', '', 'Mô tả sản phẩm', 406333.00, '20', 164, 'img/1.jpg', 7, 1, NULL, NULL, NULL),
(60, 'Nước Trái Cây Mát Vừa', '', 'Mô tả sản phẩm', 29507.00, '20', 272, 'img/34.jpg', 15, 4, NULL, NULL, NULL),
(61, 'Sữa Ngon Vừa', '', 'Mô tả sản phẩm', 94635.00, '15', 287, 'img/68.jpg', 20, 2, NULL, NULL, NULL),
(62, 'Set Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 76146.00, '20', 112, 'img/53.jpg', 94, 3, NULL, NULL, NULL),
(63, 'Ngũ Cốc Ngon Vừa', '', 'Mô tả sản phẩm', 283596.00, '20', 130, 'img/7.jpg', 20, 1, NULL, NULL, NULL),
(64, 'Nước Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 28664.00, '10', 203, 'img/31.jpg', 0, 4, NULL, NULL, NULL),
(65, 'Sữa Ngon Vừa', '', 'Mô tả sản phẩm', 85254.00, '10', 267, 'img/60.jpg', 74, 2, NULL, NULL, NULL),
(66, 'Set Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 63307.00, '0', 223, 'img/42.jpg', 82, 3, NULL, NULL, NULL),
(67, 'Ngũ Cốc Ngon Vừa', '', 'Mô tả sản phẩm', 335712.00, '0', 158, 'img/8.jpg', 94, 1, NULL, NULL, NULL),
(68, 'Nước Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 47139.00, '10', 274, 'img/23.jpg', 97, 4, NULL, NULL, NULL),
(69, 'Sữa Tươi Vừa', '', 'Mô tả sản phẩm', 92201.00, '20', 219, 'img/68.jpg', 21, 2, NULL, NULL, NULL),
(70, 'Set Trái Cây Tươi Vừa', '', 'Mô tả sản phẩm', 56544.00, '15', 296, 'img/48.jpg', 67, 3, NULL, NULL, NULL),
(71, 'Ngũ Cốc Tươi Vừa', '', 'Mô tả sản phẩm', 483120.00, '20', 257, 'img/4.jpg', 18, 1, NULL, NULL, NULL),
(72, 'Nước Trái Cây Tươi Vừa', '', 'Mô tả sản phẩm', 33374.00, '25', 213, 'img/27.jpg', 66, 4, NULL, NULL, NULL),
(73, 'Sữa Ngon Lớn', '', 'Mô tả sản phẩm', 94089.00, '10', 153, 'img/64.jpg', 79, 2, NULL, NULL, NULL),
(74, 'Set Trái Cây Ngon Lớn', '', 'Mô tả sản phẩm', 79794.00, '20', 207, 'img/44.jpg', 0, 3, NULL, NULL, NULL),
(75, 'Ngũ Cốc Ngon Lớn', '', 'Mô tả sản phẩm', 699191.00, '10', 168, 'img/9.jpg', 104, 1, NULL, '2024-06-09 22:28:34', NULL),
(76, 'Nước Trái Cây Ngon Lớn', '', 'Mô tả sản phẩm', 33853.00, '20', 141, 'img/25.jpg', 17, 4, NULL, NULL, NULL),
(77, 'Sữa Dinh Dưỡng Nhỏ', '', 'Mô tả sản phẩm', 72690.00, '0', 182, 'img/64.jpg', 98, 2, NULL, NULL, NULL),
(78, 'Set Trái Cây Dinh Dưỡng Nhỏ', '', 'Mô tả sản phẩm', 68048.00, '10', 283, 'img/40.jpg', 41, 3, NULL, NULL, NULL),
(79, 'Ngũ Cốc Dinh Dưỡng Nhỏ', '', 'Mô tả sản phẩm', 587060.00, '20', 182, 'img/9.jpg', 21, 1, NULL, NULL, NULL),
(80, 'Nước Trái Cây Dinh Dưỡng Nhỏ', '', 'Mô tả sản phẩm', 26767.00, '20', 132, 'img/28.jpg', 16, 4, NULL, NULL, NULL),
(81, 'Sữa Lạnh Vừa', '', 'Mô tả sản phẩm', 94546.00, '0', 239, 'img/61.jpg', 26, 2, NULL, NULL, NULL),
(82, 'Set Trái Cây Lạnh Vừa', '', 'Mô tả sản phẩm', 69888.00, '0', 123, 'img/44.jpg', 92, 3, NULL, NULL, NULL),
(83, 'Ngũ Cốc Lạnh Vừa', '', 'Mô tả sản phẩm', 402590.00, '20', 180, 'img/6.jpg', 30, 1, NULL, NULL, NULL),
(84, 'Nước Trái Cây Lạnh Vừa', '', 'Mô tả sản phẩm', 32611.00, '15', 173, 'img/34.jpg', 88, 4, NULL, NULL, NULL),
(85, 'Sữa Ngon Lớn', '', 'Mô tả sản phẩm', 94390.00, '10', 245, 'img/67.jpg', 13, 2, NULL, NULL, NULL),
(86, 'Set Trái Cây Ngon Lớn', '', 'Mô tả sản phẩm', 66042.00, '0', 195, 'img/52.jpg', 43, 3, NULL, NULL, NULL),
(87, 'Ngũ Cốc Ngon Lớn', '', 'Mô tả sản phẩm', 376451.00, '0', 146, 'img/11.jpg', 100, 1, NULL, '2024-06-09 22:28:34', NULL),
(88, 'Nước Trái Cây Ngon Lớn', '', 'Mô tả sản phẩm', 42526.00, '25', 297, 'img/26.jpg', 29, 4, NULL, NULL, NULL),
(89, 'Sữa Tươi Vừa', '', 'Mô tả sản phẩm', 97867.00, '15', 279, 'img/69.jpg', 27, 2, NULL, NULL, NULL),
(90, 'Set Trái Cây Tươi Vừa', '', 'Mô tả sản phẩm', 58007.00, '25', 289, 'img/49.jpg', 87, 3, NULL, NULL, NULL),
(91, 'Ngũ Cốc Tươi Vừa', '', 'Mô tả sản phẩm', 152259.00, '10', 149, 'img/1.jpg', 82, 1, NULL, NULL, NULL),
(92, 'Nước Trái Cây Tươi Vừa', '', 'Mô tả sản phẩm', 31743.00, '0', 109, 'img/23.jpg', 46, 4, NULL, NULL, NULL),
(93, 'Sữa Mát Vừa', '', 'Mô tả sản phẩm', 82380.00, '15', 223, 'img/64.jpg', 53, 2, NULL, NULL, NULL),
(94, 'Set Trái Cây Mát Vừa', '', 'Mô tả sản phẩm', 72289.00, '10', 275, 'img/55.jpg', 91, 3, NULL, NULL, NULL),
(95, 'Ngũ Cốc Mát Vừa', '', 'Mô tả sản phẩm', 231348.00, '10', 141, 'img/17.jpg', 68, 1, NULL, NULL, NULL),
(96, 'Nước Trái Cây Mát Vừa', '', 'Mô tả sản phẩm', 40000.00, '10', 104, 'img/33.jpg', 59, 4, NULL, NULL, NULL),
(97, 'Sữa Lạnh Vừa', '', 'Mô tả sản phẩm', 95063.00, '20', 159, 'img/68.jpg', 96, 2, NULL, NULL, NULL),
(98, 'Set Trái Cây Lạnh Vừa', '', 'Mô tả sản phẩm', 69954.00, '10', 102, 'img/40.jpg', 42, 3, NULL, NULL, NULL),
(99, 'Ngũ Cốc Lạnh Vừa', '', 'Mô tả sản phẩm', 594998.00, '20', 144, 'img/18.jpg', 43, 1, NULL, NULL, NULL),
(100, 'Nước Trái Cây Lạnh Vừa', '', 'Mô tả sản phẩm', 25676.00, '10', 214, 'img/26.jpg', 59, 4, NULL, NULL, NULL),
(101, 'Sữa Ngon Vừa', '', 'Mô tả sản phẩm', 91464.00, '20', 274, 'img/60.jpg', 16, 2, NULL, NULL, NULL),
(102, 'Set Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 67991.00, '15', 234, 'img/43.jpg', 75, 3, NULL, NULL, NULL),
(103, 'Ngũ Cốc Ngon Vừa', '', 'Mô tả sản phẩm', 497748.00, '20', 248, 'img/1.jpg', 38, 1, NULL, NULL, NULL),
(104, 'Nước Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 33401.00, '15', 263, 'img/23.jpg', 13, 4, NULL, NULL, NULL),
(105, 'Sữa Ngon Lớn', '', 'Mô tả sản phẩm', 77724.00, '0', 133, 'img/64.jpg', 37, 2, NULL, NULL, NULL),
(106, 'Set Trái Cây Ngon Lớn', '', 'Mô tả sản phẩm', 58512.00, '15', 150, 'img/43.jpg', 74, 3, NULL, NULL, NULL),
(107, 'Ngũ Cốc Ngon Lớn', '', 'Mô tả sản phẩm', 629617.00, '0', 196, 'img/19.jpg', 47, 1, NULL, NULL, NULL),
(108, 'Nước Trái Cây Ngon Lớn', '', 'Mô tả sản phẩm', 38445.00, '25', 112, 'img/28.jpg', 61, 4, NULL, NULL, NULL),
(109, 'Sữa Tươi Lớn', '', 'Mô tả sản phẩm', 87888.00, '10', 254, 'img/68.jpg', 42, 2, NULL, NULL, NULL),
(110, 'Set Trái Cây Tươi Lớn', '', 'Mô tả sản phẩm', 67571.00, '20', 179, 'img/41.jpg', 61, 3, NULL, NULL, NULL),
(111, 'Ngũ Cốc Tươi Lớn', '', 'Mô tả sản phẩm', 431419.00, '25', 90, 'img/17.jpg', 25, 1, NULL, '2024-06-10 00:38:50', NULL),
(112, 'Nước Trái Cây Tươi Lớn', '', 'Mô tả sản phẩm', 32633.00, '0', 133, 'img/28.jpg', 23, 4, NULL, NULL, NULL),
(113, 'Sữa Lạnh Lớn', '', 'Mô tả sản phẩm', 87896.00, '0', 109, 'img/65.jpg', 45, 2, NULL, NULL, NULL),
(114, 'Set Trái Cây Lạnh Lớn', '', 'Mô tả sản phẩm', 50294.00, '10', 191, 'img/48.jpg', 22, 3, NULL, NULL, NULL),
(115, 'Ngũ Cốc Lạnh Lớn', '', 'Mô tả sản phẩm', 724146.00, '10', 130, 'img/19.jpg', 31, 1, NULL, NULL, NULL),
(116, 'Nước Trái Cây Lạnh Lớn', '', 'Mô tả sản phẩm', 42993.00, '10', 262, 'img/29.jpg', 22, 4, NULL, NULL, NULL),
(117, 'Sữa Mát Lớn', '', 'Mô tả sản phẩm', 90534.00, '0', 223, 'img/64.jpg', 71, 2, NULL, NULL, NULL),
(118, 'Set Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 52593.00, '25', 187, 'img/50.jpg', 84, 3, NULL, '2024-06-09 04:56:39', NULL),
(119, 'Ngũ Cốc Mát Lớn', '', 'Mô tả sản phẩm', 617819.00, '15', 195, 'img/1.jpg', 55, 1, NULL, NULL, NULL),
(120, 'Nước Trái Cây Mát Lớn', '', 'Mô tả sản phẩm', 25821.00, '0', 180, 'img/25.jpg', 73, 4, NULL, NULL, NULL),
(121, 'Sữa Ngon Vừa', '', 'Mô tả sản phẩm', 83430.00, '25', 264, 'img/69.jpg', 88, 2, NULL, '2024-06-09 04:48:49', NULL),
(122, 'Set Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 78197.00, '15', 104, 'img/49.jpg', 100, 3, NULL, NULL, NULL),
(123, 'Ngũ Cốc Ngon Vừa', '', 'Mô tả sản phẩm', 618656.00, '20', 240, 'img/4.jpg', 63, 1, NULL, NULL, NULL),
(124, 'Nước Trái Cây Ngon Vừa', '', 'Mô tả sản phẩm', 96845.00, '15', 203, 'img/30.jpg', 41, 4, NULL, '2024-06-10 00:40:57', '2024-06-10 00:40:57');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('1MpRWRtuYxAERulMZ5v0iGtLWmLtXQmlrYhBxoSQ', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRlBZZm1MelFFTFVCYWRBdGNUa29EaUNadmxtMFp0bHlmMDNhYzlLVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jaGVja291dCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1718003860),
('Cg9nQPmTDl6UpmHbeXKg3qdnzaVTHZ6SZtOCShFa', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOFNXZjVqdEJwMEs5QUpYbDYzcVBtZ21RUlFyZ2RIaXZsYzVPM3hrYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hZG1pbi91c2Vycy8yL2VkaXQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1718005273),
('drT1StVtzo2nSQ1h42IWqwDtZJ73LBnXqHHc6aAS', 13, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYkxtdVVkU3p1OXg5cTZua3I3UjA3NU90SnFadmQ5V0NEb2N0RWtXcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9jaGVja291dCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjEzO30=', 1717997724),
('JwSEfsL6CTngm6x3AKSN73Ai93RIU0vX8J4Sddam', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoialRvYlV2UmJ5UXRid0VxNWs4c29qMGwwdU90dUdtYTJsczFGN3lyaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9vcmRlcnMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1717997808),
('WkrmOqiPBb5epVkWWVdxnxSojH0EUNpItbNFlVXv', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHFnSFVicnBkNzZzZGVuMHZSY2RVMGl4WHZlc2xqa2YzRjQwZU5CVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1718005030);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hoTen` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `google_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `hoTen`, `email`, `password`, `address`, `phone_number`, `role`, `status`, `remember_token`, `created_at`, `updated_at`, `google_id`) VALUES
(1, 'Quản trị viên', 'doanvanngoc061220@gmail.com', '$2y$12$ixEtk6qlgiQcozvxqw0KVef7vdY6/XR7IA7YLlKcKv7IbL4bHOS1S', 'Quỳnh Thanh', '0327630070', 'admin', 'active', NULL, '2024-05-22 05:50:01', '2024-06-09 07:28:17', NULL),
(2, 'Đoàn Ngọc', 'doanvanngoc06@gmail.com', '$2y$12$5wvuqT11QgYf36iJ0E6Xfubh25Qf3WnflWRjDhFqrDzhGLJclCkIy', 'Gò Vấp', '01111111111', 'user', 'active', NULL, '2024-05-23 06:18:27', '2024-06-10 00:41:13', NULL),
(3, 'Lương Bảo Minh', 'minh@gmail.com', '$2y$12$/vWjRELpzfwBreYnZr1dgOjrx5M0KKzE8f4UP8fz6t7ilSPG6W6DW', 'Xóm 2', '0327630071', 'user', 'active', NULL, '2024-05-24 00:21:02', '2024-05-24 00:21:02', NULL),
(4, 'Tester', 'dcuong2009@gmail.com', '$2y$12$1Y5NNMnyrpKonlRZm98Seu5Orm6aSgJwvE029a3Rrb44M0onemjjG', 'Sài Gòn', '027352642', 'user', 'active', NULL, '2024-06-02 00:24:27', '2024-06-04 22:01:39', NULL),
(5, 'Tester1', 'ngoc1234@gmail.com', '$2y$12$Q7CDDKkd7GJxtQEOWeuwOOx4bJZF5RYNhJh/RMt/oach67rK0wTdu', 'Hà Nội', '078675756', 'user', 'active', NULL, '2024-06-02 06:53:37', '2024-06-09 20:07:14', NULL),
(7, 'Minh Văn', 'minh123@gmail.com', '$2y$12$yLuFTgVM8M3E4MusP.yBpO21v8cSuZ8mFp0GpzwBh5mMKE6pf8KMS', 'Quận 12', '087868754', 'user', 'active', NULL, '2024-06-04 03:58:55', '2024-06-04 22:12:56', NULL),
(8, 'Hoàn Dương', 'duong@gmail.com', '$2y$12$SLexI6B/HusVOVqwlBvAROayV3oE.Drb7NJowqqIzngYotTrvB4G.', 'Hà Nội', '0439459743', 'user', 'inactive', NULL, '2024-06-04 21:03:46', '2024-06-04 22:16:54', NULL),
(9, 'Nguyễn Văn Long', 'long@gamil.com', '$2y$12$kFoW.N4f88q71BOvm/T5cuAO64hNsXxyI32y1DO602cGQXb/awRjm', 'TP HCM', '0348773685', 'user', 'inactive', NULL, '2024-06-05 00:09:50', '2024-06-05 00:13:21', NULL),
(10, 'Đoàn Ngọc 123', 'binh@gmail.com', '$2y$12$Jw3JgFf17uKTOacB9JLqYuXwBvOm3ECuqYDcuefTodBGGLzgoLzB.', 'Quận Tân Bình', '098678637', 'user', 'active', NULL, '2024-06-08 19:37:19', '2024-06-08 19:37:19', NULL),
(11, 'Nguyễn Văn Long', 'longnv@gmail.com', '$2y$12$FKRubDaRua1qryXDcsFj.Ou9VtaAGteoU3pY/Q3v3n8x2zw1URPPK', 'QUẬN 12', '087978665', 'user', 'active', NULL, '2024-06-08 22:55:18', '2024-06-08 22:55:18', NULL),
(12, 'ổi', 'lanhqtx2@gmail.com', '$2y$12$flmk3cvJt7WyQ3SHWWft9efrxTAsVnF66NjNkPErA17aymeq1p.ea', 'Quỳnh Thanh', '0809796868', 'user', 'active', NULL, '2024-06-09 04:48:17', '2024-06-09 04:48:17', NULL),
(13, 'jeklher', 'ngocc@gmail.com', '$2y$12$YzLYKY.FtaFe/5HoOYc61OCrW4eFUXtEUh8k4r1nyxgwdTG2nf9Ye', 'Quận 1', '023098323', 'user', 'active', NULL, '2024-06-09 22:25:29', '2024-06-09 22:25:29', NULL),
(14, 'Doan Van Ngoc (FPL HCM)', 'ngocdvps35536@fpt.edu.vn', '$2y$12$Xm5AOcINUURS5P.5Df08euO5RtPQlAvjA6luOwvdJgdU4KeBFgmg.', NULL, NULL, 'user', 'active', 'JVxLGfODMuWTJfiH3Js0EWu5U9VmQi9moeDjlJyN28968CttbM2RIag0F9Jw', '2024-06-09 22:26:00', '2024-06-09 22:26:00', '103852392040328129513');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user_voucher`
--

CREATE TABLE `user_voucher` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `voucher_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `vouchers`
--

CREATE TABLE `vouchers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `type` enum('shipping','percentage','fixed') NOT NULL,
  `value` decimal(8,2) NOT NULL,
  `expiration_date` date NOT NULL,
  `usage_limit` int(11) NOT NULL DEFAULT 1,
  `times_used` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `vouchers`
--

INSERT INTO `vouchers` (`id`, `code`, `type`, `value`, `expiration_date`, `usage_limit`, `times_used`, `created_at`, `updated_at`) VALUES
(1, 'FREESHIP', 'shipping', 35000.00, '2024-07-09', 50, 0, '2024-06-08 22:33:34', '2024-06-08 22:33:34'),
(2, 'DISCOUNT10', 'percentage', 10.00, '2024-07-09', 100, 0, '2024-06-08 22:33:34', '2024-06-08 22:33:34'),
(3, 'DISCOUNT50K', 'fixed', 50000.00, '2024-07-09', 30, 0, '2024-06-08 22:33:34', '2024-06-08 22:33:34');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Chỉ mục cho bảng `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Chỉ mục cho bảng `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_user_id_foreign` (`user_id`);

--
-- Chỉ mục cho bảng `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_items_cart_id_foreign` (`cart_id`),
  ADD KEY `cart_items_product_id_foreign` (`product_id`);

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_product_id_foreign` (`product_id`),
  ADD KEY `comments_user_id_foreign` (`user_id`);

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Chỉ mục cho bảng `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Chỉ mục cho bảng `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Chỉ mục cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`);

--
-- Chỉ mục cho bảng `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_idcat_foreign` (`idCat`);

--
-- Chỉ mục cho bảng `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_google_id_unique` (`google_id`);

--
-- Chỉ mục cho bảng `user_voucher`
--
ALTER TABLE `user_voucher`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_voucher_user_id_foreign` (`user_id`),
  ADD KEY `user_voucher_voucher_id_foreign` (`voucher_id`);

--
-- Chỉ mục cho bảng `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vouchers_code_unique` (`code`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT cho bảng `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT cho bảng `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT cho bảng `user_voucher`
--
ALTER TABLE `user_voucher`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `vouchers`
--
ALTER TABLE `vouchers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cart_items_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_idcat_foreign` FOREIGN KEY (`idCat`) REFERENCES `categories` (`id`);

--
-- Các ràng buộc cho bảng `user_voucher`
--
ALTER TABLE `user_voucher`
  ADD CONSTRAINT `user_voucher_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_voucher_voucher_id_foreign` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
