<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Chỉnh sửa đơn hàng #<?php echo e($order->id); ?></h1>
    <form method="POST" action="<?php echo e(route('admin.orders.update', $order->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="address" class="form-label">Địa chỉ:</label>
            <input type="text" class="form-control" name="address" id="address" value="<?php echo e($order->address); ?>">
        </div>
        <div class="mb-3">
            <label for="payment_method" class="form-label">Phương thức thanh toán:</label>
            <input type="text" class="form-control" name="payment_method" id="payment_method" value="<?php echo e($order->payment_method); ?>">
        </div>
        <div class="mb-3">
            <label for="status" class="form-label">Trạng thái:</label>
            <select class="form-select" name="status" id="status">
                <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="completed" <?php echo e($order->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                <option value="canceled" <?php echo e($order->status == 'canceled' ? 'selected' : ''); ?>>Canceled</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Lưu</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/admin/order_edit.blade.php ENDPATH**/ ?>