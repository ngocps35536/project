<?php $__env->startSection('content'); ?>
<div class="section-header">
    <h2>Cập nhật tài khoản</h2>
</div>
<div class="section-body">
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name">Tên người dùng</label>
                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e($user->name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phone_number">Số điện thoại</label>
                    <input type="text" name="phone_number" id="phone_number" class="form-control" value="<?php echo e($user->phone_number); ?>">
                </div>
                <div class="form-group">
                    <label for="address">Địa chỉ</label>
                    <input type="text" name="address" id="address" class="form-control" value="<?php echo e($user->address); ?>">
                </div>
                <div class="form-group">
                    <label for="role">Vai trò</label>
                    <select name="role" id="role" class="form-control">
                        <option value="user" <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>Người dùng</option>
                        <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Quản trị viên</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/admin/user-edit.blade.php ENDPATH**/ ?>