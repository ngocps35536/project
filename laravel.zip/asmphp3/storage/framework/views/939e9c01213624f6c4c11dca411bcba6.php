<?php $__env->startSection('tieudetrang'); ?>
Lịch sử đơn hàng
<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Lịch sử đơn hàng</h2>
    <?php if($orders->isNotEmpty()): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Mã đơn hàng</th>
                <th>Ngày đặt</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                <td><?php echo e(number_format($order->total_price, 0, ',', '.')); ?> VND</td>
                <td><?php echo e($order->status); ?></td>
                <td>
                    <?php if($order->status == 'pending'): ?>
                    <form action="<?php echo e(route('order.cancel', ['order' => $order->id])); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hủy đơn hàng</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>Bạn chưa có đơn hàng nào.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/history.blade.php ENDPATH**/ ?>