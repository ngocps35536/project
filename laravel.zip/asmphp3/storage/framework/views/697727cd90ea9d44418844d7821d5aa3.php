<?php $__env->startSection('title', 'Xác nhận đơn hàng'); ?>

<?php $__env->startSection('noidung'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">
                    Xác nhận đơn hàng
                </div>
                <div class="card-body">
                    <p>Mã OTP đã được nhập thành công. Đơn hàng của bạn đã được xác nhận.</p>
                    <p>Cảm ơn bạn đã mua hàng!</p>
                    <a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-primary">Xem chi tiết đơn hàng</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/order-success.blade.php ENDPATH**/ ?>