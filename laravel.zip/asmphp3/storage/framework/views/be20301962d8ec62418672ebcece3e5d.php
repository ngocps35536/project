Chào Admin! Có người một khách hàng liên hệ từ website nè:
<hr>
<p>Họ tên khách hàng <?php echo e($hoten); ?></p>
<p>Nội dung khách liên hệ : <br>

    <?php echo nl2br($noidung); ?>

<p><?php /**PATH D:\WEB4013\asmphp3\resources\views/viewMailLienHe.blade.php ENDPATH**/ ?>