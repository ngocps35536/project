<!-- resources/views/admin/products.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="section-header d-flex justify-content-between align-items-center mb-3">
    <h2>Quản lý Products</h2>
    <a href="/admin/products/create" class="btn btn-success">Thêm sản phẩm</a>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Hình ảnh</th>
            <th>Giá</th>
            <th>Số lượng</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><img src="/<?php echo e($product->image); ?>" style="width: 50px; height: 50px;"></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->quantity); ?></td>
            <td>
                <?php if($product->trashed()): ?>
                <form action="<?php echo e(route('admin.products.restore', $product->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-warning btn-sm">Khôi phục</button>
                </form>
                <form action="<?php echo e(route('admin.products.forceDelete', $product->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này vĩnh viễn?')">Xóa vĩnh
                        viễn</button>
                </form>
                <?php else: ?>
                <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-primary btn-sm">Sửa</a>
                <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')">Xóa</button>
                </form>
                <?php endif; ?>

            </td>
            </t r>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/admin/products.blade.php ENDPATH**/ ?>