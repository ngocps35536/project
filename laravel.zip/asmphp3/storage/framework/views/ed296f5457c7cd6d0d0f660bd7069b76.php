<?php $__env->startSection('tieudetrang'); ?>
Giỏ hàng
<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Giỏ hàng của bạn</h2>
    <?php if($cart && $cart->items->isNotEmpty()): ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">STT</th>
                    <th scope="col">Sản phẩm</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Giá</th>
                    <th scope="col">Tổng</th>
                    <th scope="col">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $totalPrice = 0;
                ?>
                <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $total = $item->price * $item->quantity;
                $totalPrice += $total;
                ?>
                <tr>
                    <th scope="row"><?php echo e($key + 1); ?></th>
                    <td><?php echo e($item->product->name); ?></td>
                    <td><img src="<?php echo e(asset($item->product->image)); ?>" alt="<?php echo e($item->product->name); ?>" style="max-width: 100px;"></td>
                    <td>
                        <form action="<?php echo e(route('cart.update')); ?>" method="POST" class="d-flex align-items-center">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <input type="hidden" name="cart_item_id" value="<?php echo e($item->id); ?>">
                            <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" min="1" max="<?php echo e($item->product->quantity); ?>" class="form-control me-2" style="width: 70px;">
                            <button type="submit" class="btn btn-primary btn-sm">Cập nhật</button>
                        </form>
                    </td>
                    <td><?php echo e(number_format($item->price, 0, ',', '.')); ?> VND</td>
                    <td><?php echo e(number_format($total, 0, ',', '.')); ?> VND</td>
                    <td>
                        <a href="/cart/remove/<?php echo e($item->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có muốn xóa sản phẩm khỏi giỏ hàng không?')">Xóa</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="5" class="text-end fw-bold">Tổng tiền:</td>
                    <td colspan="2"><?php echo e(number_format($totalPrice, 0, ',', '.')); ?> VND</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="text-end">
        <a href="/" class="btn btn-secondary">Tiếp tục mua hàng</a>
        <a href="/checkout" class="btn btn-success">Thanh toán</a>
    </div>
    <?php else: ?>
    <p>Giỏ
        hàng của bạn đang trống</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/showcart.blade.php ENDPATH**/ ?>