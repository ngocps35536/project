<?php $__env->startSection('tieudetrang'); ?>
Thanh toán
<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Thông tin thanh toán</h2>
    <form action="<?php echo e(route('checkout.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <h4>Thông tin người dùng</h4>
                <div class="mb-3">
                    <label for="name" class="form-label">Họ tên</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->hoTen); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Số điện thoại</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone_number); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Địa chỉ giao hàng</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address', $user->address)); ?>" required>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md-6">
                <h4>Thông tin giỏ hàng</h4>
                <div class="mb-3">
                    <label for="voucher" class="form-label">Mã giảm giá</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="voucher" name="voucher" value="<?php echo e(old('voucher')); ?>">
                        <button type="submit" class="btn btn-primary" formaction="<?php echo e(route('checkout.applyVoucher')); ?>">Áp dụng</button>
                    </div>
                    <?php if($errors->has('voucher')): ?>
                    <div class="text-danger"><?php echo e($errors->first('voucher')); ?></div>
                    <?php endif; ?>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Giá</th>
                            <th>Tổng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $totalPrice = 0;
                        $shippingFee = 35000;
                        ?>
                        <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $total = $item->price * $item->quantity;
                        $totalPrice += $total;
                        ?>
                        <tr>
                            <td><?php echo e($item->product->name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td><?php echo e(number_format($item->price, 0, ',', '.')); ?> VND</td>
                            <td><?php echo e(number_format($total, 0, ',', '.')); ?> VND</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="3" class="fw-bold">Tổng tiền sản phẩm:</td>
                            <td><?php echo e(number_format($totalPrice, 0, ',', '.')); ?> VND</td>
                        </tr>
                        <tr>
                            <td colspan="3" class="fw-bold">Phí vận chuyển:</td>
                            <td><?php echo e(number_format($shippingFee, 0, ',', '.')); ?> VND</td>
                        </tr>
                        <tr>
                            <td colspan="3" class="fw-bold">Tổng cộng:</td>
                            <td><?php echo e(number_format($totalPrice + $shippingFee, 0, ',', '.')); ?> VND</td>
                        </tr>
                    </tbody>
                </table>
                <h4>Phương thức thanh toán</h4>
                <div class="mb-3">
                    <label for="payment_method" class="form-label">Phương thức thanh toán</label>
                    <select class="form-select" id="payment_method" name="payment_method" required>
                        <option value="credit_card">Thẻ tín dụng</option>
                        <option value="bank_transfer">Chuyển khoản ngân hàng</option>
                        <option value="cash_on_delivery">Thanh toán khi nhận hàng</option>
                    </select>
                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="text-end">




            <button type="submit" class="btn btn-primary">Tiến hành thanh toán</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/thanhtoan.blade.php ENDPATH**/ ?>