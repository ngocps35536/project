<?php $__env->startComponent('mail::message'); ?>
# Xác nhận đơn hàng

Cảm ơn bạn đã đặt hàng. Mã OTP của bạn để xác nhận đơn hàng là: **<?php echo e($order->otp); ?>**

<?php $__env->startComponent('mail::button', ['url' => route('order.confirmation', ['order' => $order->id])]); ?>
Xác nhận đơn hàng
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/mailtt.blade.php ENDPATH**/ ?>