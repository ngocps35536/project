<?php $__env->startSection('tieudetrang'); ?>
Trang chủ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('noidung'); ?>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="<?php echo e(asset('img/b1.jpg')); ?>" class="d-block w-100" alt="..." height="500">
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(asset('img/b2.jpg')); ?>" class="d-block w-100" alt="..." height=500>
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(asset('img/b3.jpg')); ?>" class="d-block w-100" alt="..." height="500">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<div class="container mt-4">
    <h2 class="mb-4">Sản phẩm nổi bật</h2>
    <div class="row">
        <?php $__currentLoopData = $sphot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-3">
            <div class="card h-100" style="max-width: 300px;">
                <img src="/<?php echo e($sp->image); ?>" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Product Image">
                <div class="card-body d-flex flex-column">
                    <h6 class="card-title"><?php echo e($sp->name); ?></h6>
                    <p class="card-text"><?php echo e($sp->description); ?></p>
                    <p class="card-text highlight-price">Giá: <?php echo e(number_format($sp->price, 0, ',', '.')); ?> VND</p>
                    <div class="mt-auto d-flex justify-content-between align-items-center">
                        <a href="/pro/<?php echo e($sp->id); ?>" class="btn btn-primary btn-custom">Xem chi tiết</a>
                        <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mb-0">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($sp->id); ?>">
                            <input type="hidden" name="price" value="<?php echo e($sp->price); ?>">
                            <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <hr>
    <h2 class="mb-4">Sản phẩm xem nhiều</h2>
    <div class="row">
        <?php $__currentLoopData = $spview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-3">
            <div class="card h-100" style="max-width: 300px;">
                <img src="/<?php echo e($sp->image); ?>" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Product Image">
                <div class="card-body d-flex flex-column">
                    <h6 class="card-title"><?php echo e($sp->name); ?></h6>
                    <p class="card-text">Lượt xem: <?php echo e($sp->view); ?></p>
                    <p class="card-text highlight-price">Giá: <?php echo e(number_format($sp->price, 0, ',', '.')); ?> VND</p>
                    <div class="mt-auto d-flex justify-content-between align-items-center">
                        <a href="/pro/<?php echo e($sp->id); ?>" class="btn btn-primary btn-custom">Xem chi tiết</a>
                        <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mb-0">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($sp->id); ?>">
                            <input type="hidden" name="price" value="<?php echo e($sp->price); ?>">
                            <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<style>
    .highlight-price {
        color: #FF5733;
        font-weight: bold;
        font-size: 1em;
    }

    .btn-custom {
        flex: 1;
        margin: 0 2px;
    }
</style>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/home.blade.php ENDPATH**/ ?>