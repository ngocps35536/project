<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Danh sách đơn hàng</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Người dùng</th>
                <th>Địa chỉ</th>
                <th>Phương thức thanh toán</th>
                <th>Tổng giá</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->user->hoTen); ?></td>
                <td><?php echo e($order->address); ?></td>
                <td><?php echo e($order->payment_method); ?></td>
                <td><?php echo e($order->total_price); ?></td>
                <td><?php echo e($order->status); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-primary">Xem chi tiết</a>
                    <a href="<?php echo e(route('admin.orders.edit', $order->id)); ?>" class="btn btn-secondary">Sửa</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/admin/orders.blade.php ENDPATH**/ ?>