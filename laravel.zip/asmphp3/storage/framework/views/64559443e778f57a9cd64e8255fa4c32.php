<?php $__env->startSection('tieudetrang'); ?>
<?php echo e($detail->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('noidung'); ?>
<div class="container mt-4">
    <h2>Chi tiết sản phẩm <?php echo e($detail->name); ?></h2>
    <div class="row">
        <div class="col-md-6">
            <img src="/<?php echo e($detail->image); ?>" class="img-fluid" style="width: 50%; height: 200px; object-fit: cover;" alt="Product Image">
        </div>
        <div class="col-md-6">
            <h4>Tên sản phẩm: <?php echo e($detail->name); ?></h4>
            <p><?php echo e($detail->description); ?></p>
            <p>Lượt xem: <?php echo e($detail->view); ?></p>
            <p>Còn: <?php echo e($detail->quantity); ?> sản phẩm</p>
            <h4 class="card-text highlight-price">Giá: <?php echo e(number_format($detail->price, 0, ',', '.')); ?> VND</h4>

            <!-- Thêm input cho số lượng -->
            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mb-0">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($detail->id); ?>">
                <input type="hidden" name="price" value="<?php echo e($detail->price); ?>">
                <label for="quantity">Số lượng:</label>
                <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?php echo e($detail->quantity); ?>">
                <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
            </form>
            <!-- Kết thúc form -->

        </div>
    </div>
    <hr>
    <!-- Bình luận -->
    <div class="mt-4">
        <h3>Bình luận</h3>
        <?php if($comments->isEmpty()): ?>
        <p>Chưa có bình luận nào.</p>
        <?php else: ?>
        <ul class="list-unstyled">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mb-2">
                <strong><?php echo e($comment->hoTen); ?></strong>
                (<?php echo e(\Carbon\Carbon::parse($comment->created_at)->format('d/m/Y H:i')); ?>)<br>
                <?php echo e($comment->content); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        <!-- Form thêm bình luận -->
        <form action="<?php echo e(route('comments.store', $detail->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="content" class="form-label">Bình luận của bạn</label>
                <textarea name="content" id="content" rows="3" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Gửi bình luận</button>
        </form>
    </div>

    <div class="mt-4">
        <h3>Sản phẩm liên quan</h3>
        <div class="row">
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-3">
                <div class="card h-100">
                    <img src="/<?php echo e($sp->image); ?>" class="card-img-top img-fluid" style="width: 100%; height: 200px; object-fit: cover;" alt="Related Product Image">
                    <div class="card-body">
                        <h6 class="card-title"><?php echo e($sp->name); ?></h6>
                        <p class="card-text"><?php echo e($sp->description); ?></p>
                        <p class="card-text highlight-price">Giá: <?php echo e(number_format($sp->price, 0, ',', '.')); ?> VND</p>
                        <div class="mt-auto d-flex justify-content-between align-items-center">
                            <a href="/pro/<?php echo e($sp->id); ?>" class="btn btn-primary btn-custom">Xem chi tiết</a>
                            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mb-0">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($sp->id); ?>">
                                <input type="hidden" name="price" value="<?php echo e($sp->price); ?>">
                                <button type="submit" class="btn btn-success btn-custom">Mua ngay</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/productsDetail.blade.php ENDPATH**/ ?>