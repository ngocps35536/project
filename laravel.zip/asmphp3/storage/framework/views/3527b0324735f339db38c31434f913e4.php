<?php echo e($slot); ?>

<?php /**PATH D:\WEB4013\asmphp3\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>