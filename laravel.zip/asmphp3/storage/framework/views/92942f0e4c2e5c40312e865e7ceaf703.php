<?php $__env->startSection('title', 'Chi tiết đơn hàng'); ?>

<?php $__env->startSection('noidung'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <h2>Chi tiết đơn hàng #<?php echo e($order->id); ?></h2>
            <p><strong>Ngày đặt hàng:</strong> <?php echo e($order->created_at); ?></p>
            <p><strong>Tổng giá trị đơn hàng:</strong> <?php echo e(number_format($order->total_price, 0, ',', '.')); ?> VND</p>
            <p><strong>Phương thức thanh toán:</strong> <?php echo e($order->payment_method); ?></p>
            <hr>
            <h3>Danh sách sản phẩm</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Tên sản phẩm</th>
                        <th>Số lượng</th>
                        <th>Giá</th>
                        <th>Tổng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product_name); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e(number_format($item->price, 0, ',', '.')); ?> VND</td>
                        <td><?php echo e(number_format($item->price*$item->quantity, 0, ',', '.')); ?> VND</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <hr>
            <h3>Thông tin vận chuyển</h3>
            <p><strong>Địa chỉ giao hàng:</strong> <?php echo e($order->shipping_address); ?></p>
            <p><strong>Phí vận chuyển:</strong> <?php echo e(number_format($order->shipping_fee, 0, ',', '.')); ?> VND</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/order-details.blade.php ENDPATH**/ ?>