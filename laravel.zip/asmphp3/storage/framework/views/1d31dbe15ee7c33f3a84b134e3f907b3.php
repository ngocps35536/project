<!-- resources/views/layouts/dashboard.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Thêm CSS tùy chỉnh ở đây */
        .section-header {
            margin-top: 20px;
        }
    </style>
</head>

<body>

    <!-- Header -->
    <header class="p-3 bg-dark text-white">
        <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
                    <svg class="bi me-2" width="40" height="32">
                        <use xlink:href="#bootstrap"></use>
                    </svg>
                </a>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <li><a href="/" class="nav-link px-2 text-white">Trang chủ</a></li>
                    <li><a href="/admin/categories" class="nav-link px-2 text-white">Quản lý Categories</a></li>
                    <li><a href="/admin/products" class="nav-link px-2 text-white">Quản lý Products</a></li>
                    <li><a href="/admin/users" class="nav-link px-2 text-white">Quản lý Users</a></li>
                    <li><a href="/admin/orders" class="nav-link px-2 text-white">Quản lý Đơn hàng</a></li>
                </ul>

                <div class="text-end">
                    <a href="/" class="btn btn-outline-light me-2">Trang chủ</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main content -->
    <main class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center p-3">
        <div class="container">
            <p class="mb-0">&copy; Cửa hàng bán thực phẩm dinh dưỡng</p>
        </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH D:\WEB4013\asmphp3\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>