<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\WEB4013\asmphp3\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>