

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Chi tiết đơn hàng</h1>
    <p>ID: <?php echo e($order->id); ?></p>
    <p>Người dùng: <?php echo e($order->user->name); ?></p>
    <p>Địa chỉ: <?php echo e($order->address); ?></p>
    <p>Phương thức thanh toán: <?php echo e($order->payment_method); ?></p>
    <p>Tổng giá: <?php echo e($order->total_price); ?></p>
    <p>Trạng thái: <?php echo e($order->status); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/admin/order_item.blade.php ENDPATH**/ ?>