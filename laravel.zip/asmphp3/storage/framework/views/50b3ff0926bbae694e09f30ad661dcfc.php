<?php $__env->startSection('tieudetrang'); ?>
Xác nhận đơn hàng
<?php $__env->stopSection(); ?>

<?php $__env->startSection('noidung'); ?>
<div class="container mt-4">
    <h2 class="mb-4">Xác nhận đơn hàng</h2>
    <p>Một mã OTP đã được gửi tới email của bạn. Vui lòng nhập mã OTP để xác nhận đơn hàng.</p>
    <form action="<?php echo e(route('order.verifyOtp', ['order' => $order->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="otp" class="form-label">Mã OTP</label>
            <input type="text" class="form-control" id="otp" name="otp" required>
            <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-success">Xác nhận</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB4013\asmphp3\resources\views/confirmation.blade.php ENDPATH**/ ?>