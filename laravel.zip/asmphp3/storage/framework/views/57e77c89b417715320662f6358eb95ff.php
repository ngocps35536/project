<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('tieudetrang'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>
    <header class="p-3 bg-success text-white">
        <div class="container">
            <div class="d-flex flex-wrap align-items-center justify-content-between">
                <ul class="nav me-auto mb-2 justify-content-start mb-md-0">
                    <li><a href="/" class="nav-link px-2 text-white">Trang chủ</a></li>
                    <li><a href="#" class="nav-link px-2 text-white">Giới thiệu</a></li>
                    <li><a href="/cat/1" class="nav-link px-2 text-white">Sản phẩm</a></li>
                    <li><a href="/lienhe" class="nav-link px-2 text-white">Liên hệ</a></li>
                    <li><a href="#" class="nav-link px-2 text-white">Góp ý</a></li>
                    <li><a href="/cart" class="nav-link px-2 text-white">Giỏ hàng</a></li>
                </ul>
                <div class="d-flex align-items-center ms-auto">
                    <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-sm me-2">Đăng nhập</a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-warning btn-sm">Đăng ký</a>
                    <?php else: ?>
                    <div class="dropdown me-2">
                        <button class="btn btn-outline-light btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->hoTen); ?>

                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item" href="/profile/edit">Cập nhật hồ sơ</a></li>
                            <li><a class="dropdown-item" href="/order/history">Lịch sử mua hàng</a></li>
                            <?php if(Auth::user()->role === 'admin'): ?>
                            <li><a class="dropdown-item" href="/admin/statistics">Vào trang quản trị</a>
                            </li>
                            <?php endif; ?>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-flex align-items-center">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-light btn-sm">Đăng xuất</button>
                            </form>
                        </ul>

                    </div>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>
    <main>
        <?php echo $__env->yieldContent('noidung'); ?>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center text-lg-start">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Cửa hàng thực phẩm dinh dưỡng</h5>
                    <p>Địa chỉ: 119 Phạm Văn Chiêu, Phường 14, Quận Gò Vấp, TP.HCM</p>
                    <p>Điện thoại: (+84) 327 630 070</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Về chúng tôi</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="#!" class="text-white">Câu chuyện</a></li>
                        <li><a href="#!" class="text-white">Giới thiệu</a></li>
                        <li><a href="#!" class="text-white">Liên hệ</a></li>
                        <li><a href="#!" class="text-white">Chăm sóc khách hàng</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Chính sách</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="#!" class="text-white">Chính sách và bảo mật</a></li>
                        <li><a href="#!" class="text-white">Điều khoản sử dụng</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2024 Copyright:
            <a class="text-white" href="https://doanvanngoc.id.vn/">doanvanngoc.id.vn</a>
        </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH D:\WEB4013\asmphp3\resources\views/layout.blade.php ENDPATH**/ ?>