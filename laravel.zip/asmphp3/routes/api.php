<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ProductsController;

Route::get('sp', [ProductsController::class, 'test']);
Route::get('sp/{id}', [ProductsController::class, 'chi_tiet']);
