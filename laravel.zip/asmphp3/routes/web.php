<?php
// routes/web.php

use App\Http\Controllers\AdminController\UserController;
use App\Http\Controllers\AdminController\SanphamController;
use App\Http\Controllers\AdminController\OrderController;
use App\Http\Controllers\AdminController\CategoryController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\StatisticsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\VoucherController;
use App\Http\Middleware\CheckAdmin;
use Illuminate\Support\Facades\Route;

Route::get('/', [ProductsController::class, 'index']);
Route::get('/pro/{id}', [ProductsController::class, 'productDetail']);
Route::post('pro/{id}', [CommentController::class, 'store'])->name('comments.store')->middleware('auth');
Route::get('/cat/{id}', [ProductsController::class, 'sptrongloai']);
Route::get('/search', [ProductsController::class, 'search']);
Route::get("/lienhe", function () {
    return view('contact');
});

Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/password/reset', [AuthController::class, 'create'])->name('password.request');
Route::post('/password/email', [AuthController::class, 'store'])->name('password.email');
Route::get('/password/reset/{token}', [AuthController::class, 'showResetForm'])->name('password.reset');
Route::post('/password/reset', [AuthController::class, 'reset'])->name('password.update');

Route::get('/change-password', [AuthController::class, 'showChangePasswordForm'])->name('change-password.form');
Route::post('/change-password', [AuthController::class, 'changePassword'])->name('change-password.update');

Route::middleware('auth')->group(function () {
    Route::post('/cart/add', [CartController::class, 'addToCart'])->name('cart.add');
    Route::get('/cart/remove/{id}', [CartController::class, 'removeCartItem'])->name('cart.remove');
    Route::put('/cart/update', [CartController::class, 'updateCartItem'])->name('cart.update');
    Route::get('/cart', [CartController::class, 'showCart']);
});

Route::middleware('auth')->group(function () {
    Route::get('/checkout', [CheckoutController::class, 'showCheckout'])->name('checkout.show');
    Route::post('/checkout', [CheckoutController::class, 'processCheckout'])->name('checkout.process');
    Route::post('/checkout/apply-voucher', [CheckoutController::class, 'applyVoucher'])->name('checkout.applyVoucher');
    Route::get('/order/confirmation/{order}', [CheckoutController::class, 'showOrderConfirmation'])->name('order.confirmation');
    Route::post('/order/confirmation/{order}', [CheckoutController::class, 'verifyOtp'])->name('order.verifyOtp');
    Route::get('/order/success/{order}', [CheckoutController::class, 'showOrderSuccess'])->name('order-success');
    Route::post('/order/cancel/{order}', [CheckoutController::class, 'cancelOrder'])->name('order.cancel');
    Route::get('/order/history', [CheckoutController::class, 'showOrderHistory'])->name('order.history');
    Route::get('/orders/{order}', [CheckoutController::class, 'show'])->name('orders.show');
});

Route::get('/lienhe', [ContactController::class, 'showContactForm'])->name('contact.show');
Route::post('/guilienhe', [ContactController::class, 'sendContactEmail'])->name('contact.send');


Route::middleware([CheckAdmin::class])->group(function () {
    Route::get('/admin/products', [SanphamController::class, 'admin']);
    Route::get('/admin/products/create', [SanphamController::class, 'create']);
    Route::post('/admin/products', [SanphamController::class, 'store']);
    Route::get('/admin/products/{id}/edit', [SanphamController::class, 'edit'])->name('admin.products.edit');
    Route::put('/admin/products/{id}', [SanphamController::class, 'update'])->name('admin.products.update');
    Route::delete('/admin/products/{id}', [SanphamController::class, 'destroy'])->name('admin.products.destroy');
    Route::post('/admin/products/{id}/restore', [SanphamController::class, 'restore'])->name('admin.products.restore');
    Route::delete('/admin/products/{id}/force-delete', [SanphamController::class, 'forceDelete'])->name('admin.products.forceDelete');

    Route::get('/admin/categories', [CategoryController::class, 'index'])->name('categories.index');
    Route::get('/admin/categories/create', [CategoryController::class, 'create'])->name('categories.create');
    Route::post('/admin/categories', [CategoryController::class, 'store'])->name('categories.store');
    Route::get('/admin/categories/{category}/edit', [CategoryController::class, 'edit'])->name('categories.edit');
    Route::put('/admin/categories/{category}', [CategoryController::class, 'update'])->name('categories.update');
    Route::delete('/admin/categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');

    Route::get('/admin/users', [UserController::class, 'index'])->name('admin.users.index');
    Route::put('/admin/users/{id}/toggle-status', [UserController::class, 'toggleStatus'])->name('admin.users.toggle-status');
    Route::get('/admin/users/{id}/edit', [UserController::class, 'edit'])->name('admin.users.edit');
    Route::put('/admin/users/{id}/update', [UserController::class, 'update'])->name('admin.users.update');

    Route::get('/admin/orders', [OrderController::class, 'index'])->name('admin.orders.index');
    Route::get('/admin/orders/{id}', [OrderController::class, 'show'])->name('admin.orders.show');
    Route::get('/admin/orders/{id}/edit', [OrderController::class, 'edit'])->name('admin.orders.edit');
    Route::put('/admin/orders/{id}', [OrderController::class, 'update'])->name('admin.orders.update');
    Route::get('/admin/statistics', [StatisticsController::class, 'index'])->name('admin.statistics.index');
});

use App\Http\Controllers\GoogleLoginController;

Route::get('/login/google', [GoogleLoginController::class, 'redirectToGoogle'])->name('auth.google');
Route::get('/login/google/callback', [GoogleLoginController::class, 'handleGoogleCallback']);
